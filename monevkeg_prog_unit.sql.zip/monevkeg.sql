-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 19, 2018 at 06:16 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 5.6.33-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monevkeg`
--

-- --------------------------------------------------------

--
-- Table structure for table `program_unit`
--

CREATE TABLE `program_unit` (
  `id` smallint(6) NOT NULL,
  `id_unit` smallint(6) NOT NULL,
  `id_program` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE `unit_kerja` (
  `id` smallint(6) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `id_induk` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_kerja`
--

INSERT INTO `unit_kerja` (`id`, `unit_kerja`, `id_induk`) VALUES
(1, 'Badan Perencanaan Pembagunan, Penelitian dan Pengembangan Daerah', 0),
(2, 'Bidang Sekretariat', 1),
(3, 'Bidang Penelitian dan Pengembangan', 1),
(4, 'Bidang Pemantauan, Evaluasi Dan Pengendalian Perencanaan Pembangunan', 1),
(5, 'Bidang Perencanaan Pembangunan Ekonomi', 1),
(6, 'Bidang Perencanaan Pembangunan Sosial Budaya', 1),
(7, 'Bidang Perencanaan Wilayah Dan Pembangunan Infrastruktur', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `program_unit`
--
ALTER TABLE `program_unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_kerja`
--
ALTER TABLE `unit_kerja`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `program_unit`
--
ALTER TABLE `program_unit`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

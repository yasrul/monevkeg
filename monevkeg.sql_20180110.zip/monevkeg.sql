-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 10, 2018 at 03:11 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 5.6.32-1+ubuntu16.04.1+deb.sury.org+2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monevkeg`
--

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE `bidang` (
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Nm_Bidang` varchar(255) NOT NULL,
  `Kd_Fungsi` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`Kd_Urusan`, `Kd_Bidang`, `Nm_Bidang`, `Kd_Fungsi`) VALUES
(1, 1, 'Pendidikan', 10),
(1, 2, 'Kesehatan', 7),
(1, 3, 'Pekerjaan Umum dan Penataan Ruang', 6),
(1, 4, 'Perumahan Rakyat dan Kawasan Pemukiman', 6),
(1, 5, 'Ketentraman dan Ketertiban Umum serta Perlindungan Masyarakat', 3),
(1, 6, 'Sosial', 11),
(2, 1, 'Tenaga Kerja', 4),
(2, 2, 'Pemberdayaan Perempuan dan Perlindungan Anak', 11),
(2, 3, 'Pangan', 1),
(2, 4, 'Pertanahan', 5),
(2, 5, 'Lingkungan Hidup', 5),
(2, 6, 'Administrasi Kependudukan dan Capil', 11),
(2, 7, 'Pemberdayaan Masyarakat Desa', 4),
(2, 8, 'Pengendalian Penduduk dan Keluarga Berencana', 7),
(2, 9, 'Perhubungan', 4),
(2, 10, 'Komunikasi dan Informatika', 1),
(2, 11, 'Koperasi, Usaha Kecil dan Menengah', 4),
(2, 12, 'Penanaman Modal', 4),
(2, 13, 'Kepemudaan dan Olah Raga', 10),
(2, 14, 'Statistik', 1),
(2, 15, 'Persandian', 1),
(2, 16, 'Kebudayaan', 8),
(2, 17, 'Perpustakaan', 10),
(2, 18, 'Kearsipan', 1),
(3, 1, 'Kelautan dan Perikanan', 4),
(3, 2, 'Pariwisata', 8),
(3, 3, 'Pertanian', 4),
(3, 4, 'Kehutanan', 4),
(3, 5, 'Energi dan Sumberdaya Mineral', 4),
(3, 6, 'Perdagangan', 4),
(3, 7, 'Perindustrian', 4),
(3, 8, 'Transmigrasi', 4),
(4, 1, 'Administrasi Pemerintahan', 1),
(4, 2, 'Pengawasan', 1),
(4, 3, 'Perencanaan', 1),
(4, 4, 'Keuangan', 1),
(4, 5, 'Kepegawaian', 1),
(4, 6, 'Pendidikan dan Pelatihan', 1),
(4, 7, 'Penelitian dan Pengembangan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `file_kerja`
--

CREATE TABLE `file_kerja` (
  `id` int(11) NOT NULL,
  `id_monev` int(11) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `filename_sys` varchar(255) DEFAULT NULL,
  `filename_real` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `gender_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `gender_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `indikator`
--

CREATE TABLE `indikator` (
  `id` int(11) NOT NULL,
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `ID_Prog` smallint(6) NOT NULL,
  `Kd_Keg` smallint(6) NOT NULL,
  `Kd_Indikator` tinyint(4) NOT NULL,
  `No_ID` tinyint(4) NOT NULL,
  `Tolak_Ukur` varchar(255) DEFAULT NULL,
  `Target_Angka` decimal(10,2) DEFAULT NULL,
  `Target_Uraian` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikator`
--

INSERT INTO `indikator` (`id`, `Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `ID_Prog`, `Kd_Keg`, `Kd_Indikator`, `No_ID`, `Tolak_Ukur`, `Target_Angka`, `Target_Uraian`) VALUES
(1, 2017, 4, 3, 1, 1, 1, 106, 1, 3, 1, 'Tersedianya layanan surat menyurat ', '125.00', 'Surat'),
(2, 2017, 4, 3, 1, 1, 1, 106, 1, 4, 2, 'Kelancaran administrasi perkantoran meningkat', '1.00', 'Tahun'),
(3, 2017, 4, 3, 1, 1, 1, 106, 1, 5, 3, 'Kualitas pelayanan surat menyurat meningkat', '0.00', ''),
(4, 2017, 4, 3, 1, 1, 1, 106, 1, 6, 4, 'Tertib administrasi surat menyurat meningkat', '0.00', ''),
(5, 2017, 4, 3, 1, 1, 1, 106, 2, 3, 1, 'Jasa komunikasi, sumberdaya air, dan listrik', '1.00', 'Tahun'),
(6, 2017, 4, 3, 1, 1, 1, 106, 2, 4, 2, 'Tersedianya jasa komunikasi, sumberdaya air dan listrik', '1.00', 'Tahun'),
(7, 2017, 4, 3, 1, 1, 1, 106, 2, 5, 3, 'Tersedianya fasilitas penunjang pelaksanaan kegiatan', '0.00', ''),
(8, 2017, 4, 3, 1, 1, 1, 106, 2, 6, 4, 'Kelancaran tugas pokok dan fungsi setiap unit meningkat', '0.00', ''),
(9, 2017, 4, 3, 1, 1, 1, 106, 7, 3, 1, 'Tersedianya jasa administrasi keuangan ', '1.00', 'Tahun'),
(10, 2017, 4, 3, 1, 1, 1, 106, 7, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '1.00', 'Tahun'),
(11, 2017, 4, 3, 1, 1, 1, 106, 7, 5, 3, 'Terselenggaranya pelayanan administrasi keuangan', '0.00', ''),
(12, 2017, 4, 3, 1, 1, 1, 106, 7, 6, 4, 'Tingginya penyerapan anggaran dan capaian kinerja', '0.00', ''),
(13, 2017, 4, 3, 1, 1, 1, 106, 8, 3, 1, 'Tersedianya peralatan dan bahan pembersih kantor', '100.00', '%'),
(14, 2017, 4, 3, 1, 1, 1, 106, 8, 4, 2, 'Terciptanya lingkungan kerja yang sehat dan nyaman', '100.00', '%'),
(15, 2017, 4, 3, 1, 1, 1, 106, 8, 5, 3, 'Iklim kerja aparatur yang baik', '0.00', ''),
(16, 2017, 4, 3, 1, 1, 1, 106, 8, 6, 4, 'Kehadiran kerja aparatur ditempat kerja meningkat', '0.00', ''),
(17, 2017, 4, 3, 1, 1, 1, 106, 10, 3, 1, 'Tersedianya kebutuhan alat tulis kantor', '1.00', 'Tahun'),
(18, 2017, 4, 3, 1, 1, 1, 106, 10, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(19, 2017, 4, 3, 1, 1, 1, 106, 10, 5, 3, 'Kualitas pelaksanaan kegiatan administrasi perkantoran meningkat', '0.00', ''),
(20, 2017, 4, 3, 1, 1, 1, 106, 10, 6, 4, 'produktivitas kerja meningkat', '0.00', ''),
(21, 2017, 4, 3, 1, 1, 1, 106, 11, 3, 1, 'Tersedianya barang cetakan dan penggandaan', '1.00', 'Tahun'),
(22, 2017, 4, 3, 1, 1, 1, 106, 11, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(23, 2017, 4, 3, 1, 1, 1, 106, 11, 5, 3, 'Kualitas pelaksanaan kegiatan aadministrasi perkantoran meningkat', '0.00', ''),
(24, 2017, 4, 3, 1, 1, 1, 106, 11, 6, 4, 'Produktivitas kerja meningkat', '0.00', ''),
(25, 2017, 4, 3, 1, 1, 1, 106, 12, 3, 1, 'Tersedianya komponen instalasi listrik dan penerangan listrik bangunan kantor', '1.00', 'Unit Gedung Kantor'),
(26, 2017, 4, 3, 1, 1, 1, 106, 12, 4, 2, 'Terfasilitasinya sumber penerangan dan peralatan listrik gedung kantor', '1.00', 'Unit Gedung Kantor'),
(27, 2017, 4, 3, 1, 1, 1, 106, 12, 5, 3, 'Pelaksanaan pekerjaan perkantoran berjalan dengan baik', '0.00', ''),
(28, 2017, 4, 3, 1, 1, 1, 106, 12, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(29, 2017, 4, 3, 1, 1, 1, 106, 13, 3, 1, 'Tersedianya peralatan dan perlengkapan kantor', '246.00', 'unit/paket'),
(30, 2017, 4, 3, 1, 1, 1, 106, 13, 4, 2, 'Meningkatnya Pelayanan Administrasi Perkantoran', '100.00', '%'),
(31, 2017, 4, 3, 1, 1, 1, 106, 13, 5, 3, 'Pelaksanaan pekerjaan perkantoran berjalan dengan baik', '0.00', ''),
(32, 2017, 4, 3, 1, 1, 1, 106, 13, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(33, 2017, 4, 3, 1, 1, 1, 106, 17, 3, 1, 'Tersedianya makanan dan minuman ', '1.00', 'Tahun'),
(34, 2017, 4, 3, 1, 1, 1, 106, 17, 4, 2, 'Kelancaran administrasi perkantoran meningkat', '100.00', '%'),
(35, 2017, 4, 3, 1, 1, 1, 106, 17, 5, 3, 'Lancarnya pelaksanaan rapat koordinasi/konsultasi', '0.00', ''),
(36, 2017, 4, 3, 1, 1, 1, 106, 17, 6, 4, 'Meningkatnya pelayanan rapat koordinasi/konsultasi', '0.00', ''),
(37, 2017, 4, 3, 1, 1, 1, 106, 18, 3, 1, 'Terlaksananya rapat koordinasi dan konsultasi ke luar daerah ', '75.00', 'kali'),
(38, 2017, 4, 3, 1, 1, 1, 106, 18, 4, 2, 'Dokumen kebijakan strategis', '1.00', 'Dokumen'),
(39, 2017, 4, 3, 1, 1, 1, 106, 18, 5, 3, 'Dukungan pelaksanaan perencanaan pembangunan daerah secara nasional ', '0.00', ''),
(40, 2017, 4, 3, 1, 1, 1, 106, 18, 6, 4, 'Selarasnya perencanaan pembangunan daerah dengan perencanaan pembangunan nasional', '0.00', ''),
(41, 2017, 4, 3, 1, 1, 1, 106, 19, 3, 1, 'Tersedianya jasa administrasi teknis perkantoran', '126.00', 'orang'),
(42, 2017, 4, 3, 1, 1, 1, 106, 19, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(43, 2017, 4, 3, 1, 1, 1, 106, 19, 5, 3, 'Pelayanan aurusan administrasi dan teknis perkantoran yang cepat dan efisien', '0.00', ''),
(44, 2017, 4, 3, 1, 1, 1, 106, 19, 6, 4, 'Meningkatnya kualitas layanan administrasi umun', '0.00', ''),
(45, 2017, 4, 3, 1, 1, 1, 106, 20, 3, 1, 'Terlaksananya rapat koordinasi dengan kabupaten/kota', '68.00', 'kali'),
(46, 2017, 4, 3, 1, 1, 1, 106, 20, 4, 2, 'Dokumen kebijakan strategis', '1.00', 'Dokumen'),
(47, 2017, 4, 3, 1, 1, 1, 106, 20, 5, 5, 'Dukungan pelaksanaan perencanaan pembangunan skala regional', '0.00', ''),
(48, 2017, 4, 3, 1, 1, 1, 106, 20, 6, 6, 'Selarasnya perencanaan pembangunan provinsi dengan perencanaan pembangunan kabupaten/kota', '0.00', ''),
(49, 2017, 4, 3, 1, 1, 2, 106, 22, 3, 1, 'Terpeliharanya gedung kantor secara rutin dan berkala', '1.00', 'Unit Gedung Kantor'),
(50, 2017, 4, 3, 1, 1, 2, 106, 22, 4, 2, 'Umur fungsional gedung kantor meningkat', '1.00', 'Unit Gedung Kantor'),
(51, 2017, 4, 3, 1, 1, 2, 106, 22, 5, 3, 'Umur fungsional gedung kantor meningkat', '0.00', ''),
(52, 2017, 4, 3, 1, 1, 2, 106, 22, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(53, 2017, 4, 3, 1, 1, 2, 106, 24, 3, 1, 'Terpeliharanya secara rutin dan berkala kendaraan dinas/operasional', '81.00', 'Unit'),
(54, 2017, 4, 3, 1, 1, 2, 106, 24, 4, 2, 'Umur fungsional kendaraan dinas/operasional meningkat', '81.00', 'Unit'),
(55, 2017, 4, 3, 1, 1, 2, 106, 24, 5, 3, 'Tingkat kelancaran pelaksanaan tugas meningkat/tahun', '0.00', ''),
(56, 2017, 4, 3, 1, 1, 2, 106, 24, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(57, 2017, 4, 3, 1, 1, 2, 106, 26, 3, 1, 'Terpeliharanya secara rutin/berkala perlengkapan gedung kantor', '75.00', 'Unit'),
(58, 2017, 4, 3, 1, 1, 2, 106, 26, 4, 2, 'Umur fungsional perlengkapan gedung kantor meningkat/tahun', '75.00', 'Unit'),
(59, 2017, 4, 3, 1, 1, 2, 106, 26, 5, 3, 'Tingkat kelancaran pelaksanaan tugas meningkat', '0.00', ''),
(60, 2017, 4, 3, 1, 1, 2, 106, 26, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(61, 2017, 4, 3, 1, 1, 2, 106, 30, 3, 1, 'Terpeliharanya secara rutin/berkala peralatan kantor', '184.00', 'Unit'),
(62, 2017, 4, 3, 1, 1, 2, 106, 30, 4, 2, 'Umur fungsional peralatan kantor meningkat/tahun', '184.00', 'Unit'),
(63, 2017, 4, 3, 1, 1, 2, 106, 30, 5, 3, 'Tingkat kelancaran pelaksnaan tugas meningkat', '0.00', ''),
(64, 2017, 4, 3, 1, 1, 2, 106, 30, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(65, 2017, 4, 3, 1, 1, 2, 106, 42, 3, 1, 'Terpeliharanya gedung kantor ', '1.00', 'unit gedung kantor'),
(66, 2017, 4, 3, 1, 1, 5, 106, 1, 3, 1, 'Terselenggaranya rapat koordinasi Jabatan Fungsional Perencana (JFP)', '2.00', 'kali'),
(67, 2017, 4, 3, 1, 1, 5, 106, 1, 3, 2, 'Terselenggaranya pelatihan peningkatan kapasitas Fungsional Perencana NTB', '1.00', 'kali'),
(68, 2017, 4, 3, 1, 1, 5, 106, 1, 3, 3, 'Terselenggaranya pendidikan dan pelatihan formal bagi aparatur', '10.00', 'orang'),
(69, 2017, 4, 3, 1, 1, 5, 106, 1, 4, 4, 'Meningkatnya pemahaman peserta rapat koordinasi tentang Jabatan Fungsional Perencana (JFP)', '50.00', 'orang'),
(70, 2017, 4, 3, 1, 1, 5, 106, 1, 4, 5, 'Meningkatnya kapasitas aparatur Jabatan Fungsional Perencana (JFP)', '75.00', 'orang'),
(71, 2017, 4, 3, 1, 1, 5, 106, 1, 4, 6, 'Meningkatnya kemampuan intelektual aparatur yang mengikuti pendidikan dan pelatihan formal ', '10.00', 'orang'),
(72, 2017, 4, 3, 1, 1, 5, 106, 1, 5, 8, 'Kemapuan dalam melaksanakan tugas meningkat', '0.00', ''),
(73, 2017, 4, 3, 1, 1, 5, 106, 1, 6, 10, 'Hasil kerja atau prestasi kerja meningkat', '0.00', ''),
(74, 2017, 4, 3, 1, 1, 5, 106, 4, 3, 1, 'Terbinanya mental dan fisik aparatur', '126.00', 'orang'),
(75, 2017, 4, 3, 1, 1, 5, 106, 4, 4, 2, 'Terbinanya mental dan fisik aparatur meningkat', '126.00', 'orang'),
(76, 2017, 4, 3, 1, 1, 5, 106, 4, 5, 3, 'Gairah kerja meningkat', '0.00', ''),
(77, 2017, 4, 3, 1, 1, 5, 106, 4, 6, 4, 'Produktifitas berfikir dan keberja meningkat', '0.00', ''),
(78, 2017, 4, 3, 1, 1, 6, 106, 4, 3, 1, 'Buku Laporan Keuangan Semesteran Bappeda Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(79, 2017, 4, 3, 1, 1, 6, 106, 4, 3, 2, 'Buku laporan keuangan akhir tahun', '1.00', 'Dokumen'),
(80, 2017, 4, 3, 1, 1, 6, 106, 4, 4, 3, 'Tersusunnya  laporan keuangan semesteran Bappeda provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(81, 2017, 4, 3, 1, 1, 6, 106, 4, 4, 4, 'Tersusunnya  laporan keuangan akhir tahun Bappeda provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(82, 2017, 4, 3, 1, 1, 6, 106, 4, 5, 3, 'Tersedianya media pertanggungjawaban Bappeda yang akuntable', '0.00', ''),
(83, 2017, 4, 3, 1, 1, 6, 106, 4, 6, 4, 'Tersedianya laporan pertanggungjawaban keuangan Bappeda Provinsi NTB', '0.00', ''),
(84, 2017, 4, 3, 1, 1, 7, 106, 1, 3, 1, 'Buku Laporan Aset tahun Bappeda Provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(85, 2017, 4, 3, 1, 1, 7, 106, 1, 4, 2, 'Tersusunnya Laporan Aset tahun Bappeda Provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(86, 2017, 4, 3, 1, 1, 7, 106, 1, 5, 5, 'Tertib administrasi pengelolaan aset/barang milik daerah meningkat', '0.00', ''),
(87, 2017, 4, 3, 1, 1, 7, 106, 1, 6, 6, 'Efektifitas penggunaan aset/barang milik daerah meningkat', '0.00', ''),
(88, 2017, 4, 3, 1, 1, 15, 106, 1, 3, 1, 'Data Sistim Informasi Pembangunan Daerah Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(89, 2017, 4, 3, 1, 1, 15, 106, 1, 4, 4, 'Tersusunnya Data Sistim Informasi Pembangunan Daerah Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(90, 2017, 4, 3, 1, 1, 15, 106, 1, 5, 5, 'Tersedianya data pembangunan provinsi NTB dalam kerangka NTB 1 data', '0.00', ''),
(91, 2017, 4, 3, 1, 1, 15, 106, 1, 6, 6, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(92, 2017, 4, 3, 1, 1, 15, 106, 9, 3, 1, 'Peta Tematik Tutupan Lahan Kehutanan NTB', '1.00', 'Dokumen'),
(93, 2017, 4, 3, 1, 1, 15, 106, 9, 3, 2, 'Peta Tematik Tutupan Lahan Sawah NTB', '1.00', 'Dokumen'),
(94, 2017, 4, 3, 1, 1, 15, 106, 9, 3, 3, 'Peta Sarana/Prasarana Kesehatan 2016', '1.00', 'Dokumen'),
(95, 2017, 4, 3, 1, 1, 15, 106, 9, 3, 4, 'Peta Kesejahteraan Penduduk 2016', '1.00', 'Dokumen'),
(96, 2017, 4, 3, 1, 1, 15, 106, 9, 4, 5, 'Tersusunnya Peta Tematik Tutupan Lahan Kehutanan NTB, Peta Tematik Tutupan Lahan Sawah NTB, Peta Sarana/Prasarana Kesehatan 2016,  dan Peta Kesejahteraan Penduduk 2016', '4.00', 'Dokumen'),
(97, 2017, 4, 3, 1, 1, 15, 106, 9, 5, 6, 'Tersedianya data pembangunan provinsi NTB ', '0.00', ''),
(98, 2017, 4, 3, 1, 1, 15, 106, 9, 6, 7, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(99, 2017, 4, 3, 1, 1, 21, 106, 1, 3, 1, 'Laporan Kegiatan Pra Forum SKPD Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(100, 2017, 4, 3, 1, 1, 21, 106, 1, 3, 2, 'Laporan pelaksanaan Forum SKPD Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(101, 2017, 4, 3, 1, 1, 21, 106, 1, 3, 4, 'Laporan Kegiatan  Sarasehan Pembangunan NTB Tahun 2018', '1.00', 'Dokumen'),
(102, 2017, 4, 3, 1, 1, 21, 106, 1, 3, 5, 'Laporan Rapat Kerja  Bappeda se Provinsi NTB Tahun 2017', '1.00', 'Dokumen'),
(103, 2017, 4, 3, 1, 1, 21, 106, 1, 4, 6, 'Terselenggaranya tahapan/proses Perencanaan Pembangunan Daerah Tahun 2017', '4.00', 'Kegiatan'),
(104, 2017, 4, 3, 1, 1, 21, 106, 1, 4, 7, 'Tersusunnya sistem informasi Bappeda terpadu', '1.00', 'dokumen'),
(105, 2017, 4, 3, 1, 1, 21, 106, 1, 5, 9, 'Peningkatan sinkronisasi rencana kerja', '0.00', ''),
(106, 2017, 4, 3, 1, 1, 21, 106, 1, 6, 11, 'Selarasnya rencana program pembangunan daerah ', '0.00', ''),
(107, 2017, 4, 3, 1, 1, 21, 106, 8, 3, 1, 'Dokumen RKPD Perubahan Provinsi NTB TA 2017 dan Dokumen RKPD Provinsi NTB TA 2018', '2.00', 'Dokumen'),
(108, 2017, 4, 3, 1, 1, 21, 106, 8, 4, 9, 'Tersusunnya dokumen RKPD Perubahan Provinsi NTB Tahun 2017 dan Dokumen RKPD Provinsi NTB Tahun 2018', '2.00', 'Dokumen'),
(109, 2017, 4, 3, 1, 1, 21, 106, 8, 5, 7, 'Perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(110, 2017, 4, 3, 1, 1, 21, 106, 8, 6, 8, 'Pembangunan tahunan yang terarah, efektif dan efisien', '0.00', ''),
(111, 2017, 4, 3, 1, 1, 21, 106, 9, 3, 1, 'Dokumen Perencanaan Pembangunan Daerah Tahun 2018', '1.00', 'Dokumen'),
(112, 2017, 4, 3, 1, 1, 21, 106, 9, 4, 2, 'Terselenggaranya kegiatan Pra Musrenbang dan Musrenbang RKPD Provinsi NTB ', '1.00', 'Kegiatan'),
(113, 2017, 4, 3, 1, 1, 21, 106, 9, 5, 3, 'Meningkatnya peran masyarakat dalam proses perencanaan pembangunan', '0.00', ''),
(114, 2017, 4, 3, 1, 1, 21, 106, 9, 6, 4, 'Sistem perencanaan pembangunan daerah yang selaras dan efektif', '0.00', ''),
(115, 2017, 4, 3, 1, 1, 21, 106, 11, 3, 1, 'Laporan Kinerja Instansi Pemerintah (LKjIP) Bappeda Provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(116, 2017, 4, 3, 1, 1, 21, 106, 11, 4, 3, 'Tersusunnya Laporan Kinerja Instansi Pemerintah (LKjIP) Bappeda Provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(117, 2017, 4, 3, 1, 1, 21, 106, 11, 5, 8, 'Tersedianya media pertanggungjawaban Bappeda yang akuntable', '0.00', ''),
(118, 2017, 4, 3, 1, 1, 21, 106, 11, 6, 10, 'Meningkatnya akuntabilitas dan kredibilitas hasil pelaksanaan kegiatan Bappeda', '0.00', ''),
(119, 2017, 4, 3, 1, 1, 21, 106, 12, 3, 1, 'Dokumen Laporan LKPJ Gubernur Tahun 2016', '1.00', 'Dokumen'),
(120, 2017, 4, 3, 1, 1, 21, 106, 12, 4, 2, 'Terinformasikannya capaian kinerja pelaksanaan program pembangunan daerah yang akuntabel', '100.00', '%'),
(121, 2017, 4, 3, 1, 1, 21, 106, 12, 5, 3, 'Meningkatnya kualitas perencanaan pembangunan', '0.00', ''),
(122, 2017, 4, 3, 1, 1, 21, 106, 12, 6, 4, 'Pertanggungjawaban yang akuntabel', '0.00', ''),
(123, 2017, 4, 3, 1, 1, 21, 106, 13, 3, 1, 'Penyusunan Dokumen Evaluasi Program Prioritas RPJMD Provinsi NTB Semester I dan Semester II TA. 2017', '2.00', 'Dokumen'),
(124, 2017, 4, 3, 1, 1, 21, 106, 13, 3, 2, 'Penyusunan/Penulisan Evaluasi Triwulanan APBN Triwulan IV TA. 2016 dan Triwulan I, II dan III TA. 2017', '4.00', 'Dokumen'),
(125, 2017, 4, 3, 1, 1, 21, 106, 13, 3, 3, ' Dokumen Sinkronisasi Program Kegiatan APBN (Dekonsentrasi, Tugas Pembantuan dan Urusan Bersama) dengan Program/Kegiatan APBD Tahun Anggaran 2017', '1.00', 'Dokumen'),
(126, 2017, 4, 3, 1, 1, 21, 106, 13, 3, 4, 'Penyusunan dokumen Evaluasi RKPD SKPD Provinsi dan Kabupaten/Kota Triwulan I, II, III dan IV TA. 2017', '4.00', 'Dokumen'),
(127, 2017, 4, 3, 1, 1, 21, 106, 13, 4, 6, 'Terevaluasinya dan terpantaunya program/kegiatan pembangunan daerah', '0.00', ''),
(128, 2017, 4, 3, 1, 1, 21, 106, 13, 5, 8, 'Perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(129, 2017, 4, 3, 1, 1, 21, 106, 13, 6, 9, 'Perencanaan pembangunan yang tepat sasaran', '0.00', ''),
(130, 2017, 4, 3, 1, 1, 21, 106, 14, 3, 1, 'Dokumen KUA dan PPAS Perubahan TA. 2017 dan Dokumen KUA dan PPAS Tahun 2018', '4.00', 'Dokumen'),
(131, 2017, 4, 3, 1, 1, 21, 106, 14, 4, 3, 'Tersedianya bahan penyusunan RAPBD perubahan TA. 2017 dan RAPBD TA. 2018', '4.00', 'Dokumen'),
(132, 2017, 4, 3, 1, 1, 21, 106, 14, 5, 4, 'Pengesahan APBDP TA. 2017 dan APBD TA. 2018', '0.00', ''),
(133, 2017, 4, 3, 1, 1, 21, 106, 14, 6, 5, 'Terselenggaranya pembangunan Tahun 2017 dan 2018', '0.00', ''),
(134, 2017, 4, 3, 1, 1, 21, 106, 15, 3, 1, 'Dokumen Rencana Kerja (Renja) Perubahan Bappeda Provinsi NTB Tahun 2017, dan Renja Bappeda Provinsi NTB Tahun 2018', '2.00', 'Dokumen'),
(135, 2017, 4, 3, 1, 1, 21, 106, 15, 3, 2, 'Rencana Kerja Anggaran (RKA) Perubahan Bappeda Provinsi NTB Tahun Anggaran 2017 dan RKA Bappeda Provinsi NTB Tahun 2018', '2.00', 'Dokumen'),
(136, 2017, 4, 3, 1, 1, 21, 106, 15, 3, 3, 'Laporan Tahunan Pelaksanaan Program dan Kegiatan Bappeda Provinsi NTB Tahun 2016', '1.00', 'Dokumen'),
(137, 2017, 4, 3, 1, 1, 21, 106, 15, 3, 4, 'Laporan Capaian Rencana Aksi Indikator Kinerja Bappeda', '1.00', 'Dokumen'),
(138, 2017, 4, 3, 1, 1, 21, 106, 15, 3, 5, 'Terlaksananya pembahasan/asistensi  Pra RKA Perubahan SKPD Lingkup Pemerintah Provinsi NTB TA. 2017 dan pembahasan/asistensi  Pra RKA SKPD Lingkup Pemerintah Provinsi NTB TA. 2018 ', '2.00', 'Kegiatan'),
(139, 2017, 4, 3, 1, 1, 21, 106, 15, 4, 10, 'Tersusunnya Dokumen Perencanaan Pembangunan Tahun 2016', '6.00', 'Dokumen'),
(140, 2017, 4, 3, 1, 1, 21, 106, 15, 5, 14, 'Tersedianya dokumen-dokumen perencanaan pembangunan daerah', '0.00', ''),
(141, 2017, 4, 3, 1, 1, 21, 106, 15, 6, 15, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(142, 2017, 4, 3, 1, 1, 21, 106, 16, 3, 1, 'Terselenggaranya sosialisasi/publikasi hasil perencanaan pembangunan daerah', '1.00', 'Tahun'),
(143, 2017, 4, 3, 1, 1, 21, 106, 16, 4, 2, 'Tersosialisasinya/terpublikasinya hasil perencanaan pembangunan daerah', '1.00', 'Tahun'),
(144, 2017, 4, 3, 1, 1, 21, 106, 16, 5, 3, 'Pengetahuan masyarakat tentang hasil perencanaan pembangunan daerah meningkat', '0.00', ''),
(145, 2017, 4, 3, 1, 1, 21, 106, 16, 6, 4, 'Masyarakat berupaya berpartisipasi dalam perencanaan pembangunan', '0.00', ''),
(146, 2017, 4, 3, 1, 1, 21, 106, 18, 3, 1, 'Dokumen Laporan Sinkronisasi RPKD, KUA-PPAS, APBD Perubahan 2017 dan APBD Murni 2018 Kabupaten/Kota', '1.00', 'Dokumen'),
(147, 2017, 4, 3, 1, 1, 21, 106, 18, 4, 2, 'Tersedianya bahan perencanaan pembangunan daerah', '1.00', 'Dokumen'),
(148, 2017, 4, 3, 1, 1, 21, 106, 18, 5, 3, 'Perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(149, 2017, 4, 3, 1, 1, 21, 106, 18, 6, 4, 'Sistem perencanaan pembangunan yang selaras dan efektif', '0.00', ''),
(150, 2017, 4, 3, 1, 1, 21, 106, 21, 3, 1, 'Aplikasi e-planning (e-Musrenbang, e-Renja SKPD, e-Pokir, e-R RKPD, e-R KUA PPAS, e-RPJMD, e-Renstra', '7.00', 'Aplikasi'),
(151, 2017, 4, 3, 1, 1, 21, 106, 21, 4, 2, 'Aplikasi e-planning ', '7.00', 'Aplikasi'),
(152, 2017, 4, 3, 1, 1, 21, 106, 21, 5, 3, 'Perencanaan pembangunan berbasis elektronik', '0.00', ''),
(153, 2017, 4, 3, 1, 1, 21, 106, 21, 6, 4, 'Sistem perencanaan pembangunan yang selaras dan efektif', '0.00', ''),
(154, 2017, 4, 3, 1, 1, 21, 106, 22, 3, 1, 'Dokumen Sinkronisasi RPJMD Provinsi NTB dengan RPJMD Kab/Kota', '1.00', 'Dokumen'),
(155, 2017, 4, 3, 1, 1, 21, 106, 22, 4, 2, 'RPJMD Provinsi yang selaras dengan RPJMD Kab/Kota', '1.00', 'Dokumen'),
(156, 2017, 4, 3, 1, 1, 21, 106, 22, 5, 3, 'Perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(157, 2017, 4, 3, 1, 1, 21, 106, 22, 6, 4, 'Sistem perencanaan pembangunan yang selaras dan efektif', '0.00', ''),
(158, 2017, 4, 3, 1, 1, 22, 106, 3, 3, 1, 'Laporan Pelaksanaan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'Dokumen'),
(159, 2017, 4, 3, 1, 1, 22, 106, 3, 3, 2, 'Laporan Pelaksanaan Bimtek P3BM', '1.00', 'Dokumen'),
(160, 2017, 4, 3, 1, 1, 22, 106, 3, 3, 3, 'Laporan Hasil Rapat Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'Dokumen'),
(161, 2017, 4, 3, 1, 1, 22, 106, 3, 3, 4, 'Laporan hasil  Rapat Program Peningkatan Penghidupan Berkelanjutan (P2B) - PKKPM dan PIE', '1.00', 'Dokumen'),
(162, 2017, 4, 3, 1, 1, 22, 106, 3, 4, 5, 'Terlaksananya kegiatan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'Kegiatan'),
(163, 2017, 4, 3, 1, 1, 22, 106, 3, 4, 6, 'Tersusunnya Kebijakan tentang Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'Dokumen'),
(164, 2017, 4, 3, 1, 1, 22, 106, 3, 4, 7, 'Tersusunnya Kebijakan Program Peningkatan Penghidupan Berkelanjutan (P2B) - PKKPM dan PIE', '1.00', 'Dokumen'),
(165, 2017, 4, 3, 1, 1, 22, 106, 3, 4, 8, 'Terlaksananya kegiatan Bimtek P3BM', '1.00', 'Kegiatan'),
(166, 2017, 4, 3, 1, 1, 22, 106, 3, 5, 9, 'Dokumen perencanaan pengembangan ekonomi masyarakat dapat menjadi rujukan pemerintah, masyarakat, dan dunia usaha untuk pembangunan ekonomi lebih lanjut', '0.00', ''),
(167, 2017, 4, 3, 1, 1, 22, 106, 3, 6, 10, 'Penyempurnaan terhadap ekonomi perencanaan pembangunan ekonomi masyarakat', '0.00', ''),
(168, 2017, 4, 3, 1, 1, 22, 106, 4, 3, 1, 'Bahan Dokumen Perencanaan Pembangunan Ekonomi Subbidang Industri dan Keuangan', '1.00', 'Dokumen'),
(169, 2017, 4, 3, 1, 1, 22, 106, 4, 3, 2, 'Buku Database Capaian Indikator MDGs', '1.00', 'Dokumen'),
(170, 2017, 4, 3, 1, 1, 22, 106, 4, 3, 3, 'Buku Laporan Tahunan MDGs NTB', '1.00', 'Dokumen'),
(171, 2017, 4, 3, 1, 1, 22, 106, 4, 3, 4, 'Dokumen pelaksanaan KEK Provinsi NTB', '1.00', 'Dokumen'),
(172, 2017, 4, 3, 1, 1, 22, 106, 4, 3, 5, 'Dokumen Pelaksanaan PNPM PISEW', '1.00', 'Dokumen'),
(173, 2017, 4, 3, 1, 1, 22, 106, 4, 4, 9, 'Tersusunnya Dokumen Perencanaan Pembangunan Ekonomi Subbidang Industri dan Keuangan', '1.00', 'Dokumen'),
(174, 2017, 4, 3, 1, 1, 22, 106, 4, 4, 10, 'Tersusunnya dokumen Pelaksanaan Kegiatan, KEK, PISEW dan Capaian Target MDGs di Provinsi NTB', '1.00', 'Dokumen'),
(175, 2017, 4, 3, 1, 1, 22, 106, 4, 5, 11, 'Dokumen perencanaan pembangunan ekonomi sebagai salah satu acuan dalam pelaksanaan program/kegiatan bidang ekonomi', '0.00', ''),
(176, 2017, 4, 3, 1, 1, 22, 106, 4, 6, 12, 'Penyempurnaan terhadap dokumen perencanaan pembangunan bidang ekonomi', '0.00', ''),
(177, 2017, 4, 3, 1, 1, 22, 106, 10, 3, 1, ' Dokumen Pelaksanaan Kegiatan DBHCHT Provinsi NTB', '1.00', 'Dokumen'),
(178, 2017, 4, 3, 1, 1, 22, 106, 10, 3, 3, 'Terkoordinasinya program/kegiatan  DBHCHT', '1.00', 'Kegiatan'),
(179, 2017, 4, 3, 1, 1, 22, 106, 10, 3, 4, 'Terlaksananya Rapat Koordinasi DBHCHT', '1.00', 'Kegiatan'),
(180, 2017, 4, 3, 1, 1, 22, 106, 10, 3, 5, 'Terlaksananya Rekonsiliasi DBHCHT', '1.00', 'Kegiatan'),
(181, 2017, 4, 3, 1, 1, 22, 106, 10, 3, 6, 'Terkoordinasnya Pelaksanaan Ketentuan di bidang cukai', '1.00', 'Kegiatan'),
(182, 2017, 4, 3, 1, 1, 22, 106, 10, 4, 7, 'Rapat  Koordinasi  DBHCHT', '85.00', 'Orang'),
(183, 2017, 4, 3, 1, 1, 22, 106, 10, 4, 9, 'Rekonsiliasi DBHCHT', '60.00', 'Orang'),
(184, 2017, 4, 3, 1, 1, 22, 106, 10, 4, 10, 'Hasil Monitoring  dan Evaluasi ketentuan di bidang cukai', '1.00', 'Kegiatan'),
(185, 2017, 4, 3, 1, 1, 22, 106, 10, 4, 13, 'Tersusunnya Dokumen Pelaksanaan Kegiatan DBHCHT Provinsi NTB', '1.00', 'dokumen'),
(186, 2017, 4, 3, 1, 1, 22, 106, 10, 5, 11, 'Dokumen pelaksanaan kegiatan DBH-CHT dapat menjadi acuan dalam pengelolaan DBH-CHT di NTB', '0.00', ''),
(187, 2017, 4, 3, 1, 1, 22, 106, 10, 6, 12, 'Tersedianya data dan infotmasi tentang program/kegiatan DBHCHT di NTB', '0.00', ''),
(188, 2017, 4, 3, 1, 1, 22, 106, 11, 3, 2, 'Dokumen Perencanaan Pembangunan Ekonomi Investasi dan Keuangan', '1.00', 'Dokumen'),
(189, 2017, 4, 3, 1, 1, 22, 106, 11, 3, 3, 'Draft Rencana Aksi Daerah (RAD) SDGs di Provinsi NTB', '1.00', 'Dokumen'),
(190, 2017, 4, 3, 1, 1, 22, 106, 11, 4, 6, 'Tersusunnya Dokumen Perencanaan Pembangunan Ekonomi Investasi dan Keuangan', '1.00', 'Dokumen'),
(191, 2017, 4, 3, 1, 1, 22, 106, 11, 4, 7, 'Tersusunnya Dokumen SDGs Provinsi NTB (Draft Rencana Aksi Dawrah, Data Base dan Laporan Tahunan)', '1.00', 'Dokumen '),
(192, 2017, 4, 3, 1, 1, 22, 106, 11, 5, 10, 'Dokumen perencanaan pembangunan ekonomi sebagai salah satu acuan dalam pelaksanaan program/kegiatan bidang ekonomi', '0.00', ''),
(193, 2017, 4, 3, 1, 1, 22, 106, 11, 6, 11, 'Penyempurnaan terhadap dokumen perencanaan pembangunan bidang ekonomi', '0.00', ''),
(194, 2017, 4, 3, 1, 1, 22, 106, 12, 3, 1, 'Dokumen Perencanaan Pembangunan Ekonomi Perindustrian, Perdagangan dan Pariwisata', '1.00', 'Dokumen'),
(195, 2017, 4, 3, 1, 1, 22, 106, 12, 3, 2, 'Dokumen pelaksanaan KEK Provinsi NTB (SEM I,SEM II  dan Laporan akhir)', '3.00', 'Dokumen'),
(196, 2017, 4, 3, 1, 1, 22, 106, 12, 4, 5, 'Tersusunnya Dokumen Perencanaan Pembangunan Ekonomi Perindustrian, Perdagangan dan Pariwisata', '1.00', 'Dokumen'),
(197, 2017, 4, 3, 1, 1, 22, 106, 12, 4, 6, 'Tersusunnya Dokumen pelaksanaan KEK Provinsi NTB (SEM I,SEM II  dan Laporan akhir)', '3.00', 'Dokumen'),
(198, 2017, 4, 3, 1, 1, 22, 106, 12, 5, 8, 'Dokumen perencanaan pembangunan ekonomi sebagai salah satu acuan dalam pelaksanaan program/kegiatan bidang ekonomi', '0.00', ''),
(199, 2017, 4, 3, 1, 1, 22, 106, 12, 6, 9, 'Penyempurnaan terhadap dokumen perencanaan pembangunan bidang ekonomi', '0.00', ''),
(200, 2017, 4, 3, 1, 1, 22, 106, 13, 3, 1, 'Dokumen Perencanaan Bidang Pangan dan Pertanian', '1.00', 'Dokumen'),
(201, 2017, 4, 3, 1, 1, 22, 106, 13, 3, 2, 'Dokumen Pelaksanaan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'Dokumen'),
(202, 2017, 4, 3, 1, 1, 22, 106, 13, 3, 12, 'Meningkatnya pemahaman bimtek analisis belanja publik penanggulangan kemiskinan Provinsi NTB', '65.00', 'orang'),
(203, 2017, 4, 3, 1, 1, 22, 106, 13, 3, 13, 'Meningkatnya pemahaman tentang kebijakan penanggulangan kemiskinan Provinsi NTB', '60.00', 'orang'),
(204, 2017, 4, 3, 1, 1, 22, 106, 13, 3, 14, 'Meningkatnya sinergisitas program antar stakeholder penanggulangan kemiskinan di daerah', '80.00', 'orang'),
(205, 2017, 4, 3, 1, 1, 22, 106, 13, 4, 4, 'Tersusunnya  Dokumen Perencanaan Bidang Pangan dan Pertanian', '1.00', 'Dokumen'),
(206, 2017, 4, 3, 1, 1, 22, 106, 13, 4, 6, 'Tersusunnya Dokumen Pelaksanaan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'Dokumen'),
(207, 2017, 4, 3, 1, 1, 22, 106, 13, 4, 15, 'Terselenggaranya bimtek analisis belanja publik penanggulangan kemiskinan Provinsi NTB', '1.00', 'kegiatan'),
(208, 2017, 4, 3, 1, 1, 22, 106, 13, 4, 16, 'Terselenggaranya rapat koordinasi penanggulangan kemiskinan Provinsi NTB', '1.00', 'kegiatan'),
(209, 2017, 4, 3, 1, 1, 22, 106, 13, 4, 17, 'Terselenggaranya rapat teknis penanggulangan kemiskinan', '2.00', 'kegiatan'),
(210, 2017, 4, 3, 1, 1, 22, 106, 13, 5, 10, 'Dokumen perencanaan pengembangan ekonomi masyarakat dapat menjadi rujukan pemerintah, masyarakat, dan dunia usaha untuk pembangunan ekonomi lebih lanju', '0.00', ''),
(211, 2017, 4, 3, 1, 1, 22, 106, 13, 6, 11, 'Penyempurnaan terhadap ekonomi perencanaan pembangunan ekonomi masyarakat', '0.00', ''),
(212, 2017, 4, 3, 1, 1, 23, 106, 5, 3, 1, 'Dokumen Evaluasi Pelaksanaan Program/Kegiatan Bidang Sosial', '1.00', 'Dokumen'),
(213, 2017, 4, 3, 1, 1, 23, 106, 5, 3, 2, 'Buku saku kegiatan subbid pemerintahan', '1.00', 'Dokumen'),
(214, 2017, 4, 3, 1, 1, 23, 106, 5, 3, 3, 'Tersedianya data dan terjalinnya koordinasi dengan SKPD MItra', '1.00', 'Kegiatan'),
(215, 2017, 4, 3, 1, 1, 23, 106, 5, 4, 4, 'Tersusunnya Dokumen Evaluasi Pelaksanaan Program/Kegiatan Bidang Sosial', '1.00', 'Dokumen'),
(216, 2017, 4, 3, 1, 1, 23, 106, 5, 4, 5, 'Tersusunnya data dan terjalinnya koordinasi dengan SKPD MItra', '1.00', 'Dokumen'),
(217, 2017, 4, 3, 1, 1, 23, 106, 5, 5, 6, 'Terciptanya perencanaan yang efektif dan efisien', '0.00', ''),
(218, 2017, 4, 3, 1, 1, 23, 106, 5, 6, 7, 'Tercapainya target pembangunan sesuai RPJMD', '0.00', ''),
(219, 2017, 4, 3, 1, 1, 23, 106, 8, 3, 1, 'Dokumen Evaluasi Rencana Aksi Daerah Pangan dan Gizi (RAD - PG)', '1.00', 'Dokumen'),
(220, 2017, 4, 3, 1, 1, 23, 106, 8, 3, 2, 'Terlaksananya kegiatan Fasilitasi Perencanaan Pembangunan Kesejahteraan Sosial', '1.00', 'Kegiatan'),
(221, 2017, 4, 3, 1, 1, 23, 106, 8, 3, 3, 'Terlaksananya kegiatan sosialisasi Perda No 7 Tahun 2015', '1.00', 'kegiatan'),
(222, 2017, 4, 3, 1, 1, 23, 106, 8, 3, 4, 'Terlaksananya kegiatan Fasilitasi Gugus Tugas Kota Layak Anak', '1.00', 'Kegiatan'),
(223, 2017, 4, 3, 1, 1, 23, 106, 8, 4, 8, 'Tersusunnya Dokumen Evaluasi Rencana Aksi Daerah Pangan dan Gizi (RAD - PG)', '1.00', 'Dokumen'),
(224, 2017, 4, 3, 1, 1, 23, 106, 8, 4, 9, 'Tersosialisasinya Perda No 7 Tahun 2015', '1.00', 'Kegiatan'),
(225, 2017, 4, 3, 1, 1, 23, 106, 8, 4, 10, 'Terfasilitasinya kegiatan perencanaan pembangunan kesejahteraan sosial', '1.00', 'kegiatan'),
(226, 2017, 4, 3, 1, 1, 23, 106, 8, 5, 11, 'Tercapainya indkator kinerja Bidang Sosial/Sub Bidang Kesra', '0.00', ''),
(227, 2017, 4, 3, 1, 1, 23, 106, 8, 6, 12, 'Meningkatnya kesehatan dan kecerdasan masyarakat NTB', '0.00', ''),
(228, 2017, 4, 3, 1, 1, 23, 106, 9, 3, 4, 'Tersebarnya Pergub No. 38 Tahun 2015 tentang Bale Mediasi', '1.00', 'Kegiatan'),
(229, 2017, 4, 3, 1, 1, 23, 106, 9, 4, 6, 'Terselenggaranya Sosialisasi Peraturan Gubernur No. 38 Tahun 2015 tentang Bale Mediasi', '1.00', 'Kegiatan'),
(230, 2017, 4, 3, 1, 1, 23, 106, 9, 5, 7, 'Meningkatnya pemahaman masyarakat tentang Bale Mediasi ', '0.00', ''),
(231, 2017, 4, 3, 1, 1, 23, 106, 9, 5, 9, 'Meningkatnya penyelesaian sengketa di luar pengadilan', '0.00', ''),
(232, 2017, 4, 3, 1, 1, 23, 106, 9, 6, 10, 'Meningkatnya capaian target Indikator Kinerja Sub Bidang Pemerintahan', '0.00', ''),
(233, 2017, 4, 3, 1, 1, 23, 106, 10, 3, 1, 'Terselenggaranya pelaporan AD-PPK', '4.00', 'Dokumen'),
(234, 2017, 4, 3, 1, 1, 23, 106, 10, 4, 2, 'Tersedianya Laporan Aksi Daerah Pencegahan dan Pemberantasan Korupsi (AD-PPK)', '1.00', 'Dokumen'),
(235, 2017, 4, 3, 1, 1, 23, 106, 10, 4, 3, 'Terlaksananya Kegiatan Rapat Koordinasi AD-PPK', '1.00', 'Kegiatan'),
(236, 2017, 4, 3, 1, 1, 23, 106, 10, 5, 4, 'Meningktnya pelaksanaan pencegahan dan pemberantasan Korupsi', '0.00', ''),
(237, 2017, 4, 3, 1, 1, 23, 106, 10, 6, 5, 'Meningkatnya tata kelola pemerintahan yang baik', '0.00', ''),
(238, 2017, 4, 3, 1, 1, 23, 106, 11, 3, 1, 'Laporan Evaluasi Pendidikan Dasar dan Menengah', '1.00', 'Dokumen'),
(239, 2017, 4, 3, 1, 1, 23, 106, 11, 3, 2, 'Terlaksananya Rapat Koordinasi Generasi Emas NTB', '1.00', 'kegiatan'),
(240, 2017, 4, 3, 1, 1, 23, 106, 11, 4, 5, 'Tersusunnya Laporan Evaluasi Pendidikan Dasar dan Menengah', '1.00', 'Dokumen'),
(241, 2017, 4, 3, 1, 1, 23, 106, 11, 5, 7, 'Tercapainya indkator kinerja Bidang Pendidikan dan Kesehatan', '0.00', ''),
(242, 2017, 4, 3, 1, 1, 23, 106, 11, 6, 8, 'Meningkatnya kesehatan dan kecerdasan masyarakat NTB', '0.00', ''),
(243, 2017, 4, 3, 1, 1, 24, 106, 2, 3, 1, 'Laporan Penurunan Emisi Gas Rumah Kaca', '1.00', 'Dokumen'),
(244, 2017, 4, 3, 1, 1, 24, 106, 2, 3, 2, 'Laporan Pelaksanaan Geopark Rinjani dan Tambora', '1.00', 'Dokumen'),
(245, 2017, 4, 3, 1, 1, 24, 106, 2, 3, 3, 'Laporan Pelaksanaan Program Kemakmuran Hijau', '1.00', 'Dokumen'),
(246, 2017, 4, 3, 1, 1, 24, 106, 2, 4, 6, 'Terpantaunya Emisi Gas Rumah Kaca di NTB', '1.00', 'Tahun'),
(247, 2017, 4, 3, 1, 1, 24, 106, 2, 4, 7, 'Terkoordinasinya Pelaksanaan Program Compact Kemakmuran hijau', '1.00', 'Tahun'),
(248, 2017, 4, 3, 1, 1, 24, 106, 2, 4, 8, 'Terkoordinasinya Pelaksanaan Geopark Rinjani dan Tambora', '1.00', 'Tahun'),
(249, 2017, 4, 3, 1, 1, 24, 106, 2, 5, 9, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(250, 2017, 4, 3, 1, 1, 24, 106, 2, 6, 10, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(251, 2017, 4, 3, 1, 1, 24, 106, 7, 3, 1, 'Dokumen Evaluasi DAK Bidang Infrastruktur Tahun 2016', '1.00', 'Dokumen'),
(252, 2017, 4, 3, 1, 1, 24, 106, 7, 3, 2, 'Dokumen Hasil Penyelarasan Program/Kegiatan Bidang Prasarana Wilayah', '1.00', 'Dokumen'),
(253, 2017, 4, 3, 1, 1, 24, 106, 7, 3, 3, 'Rapat Koordinasi Infrastruktur Sinergis yang dilaksanakan', '1.00', 'Kegiatan'),
(254, 2017, 4, 3, 1, 1, 24, 106, 7, 3, 4, 'Rapat Koordinasi DAK Infrasturktur yang dilaksanakan', '1.00', 'Kegiatan'),
(255, 2017, 4, 3, 1, 1, 24, 106, 7, 3, 11, 'Dokumen profil infrastruktur strategis', '1.00', 'dokumen'),
(256, 2017, 4, 3, 1, 1, 24, 106, 7, 4, 7, 'Terselenggaranya Koordinasi perencanaan bidang prasarana wilayah', '1.00', 'Kegiatan'),
(257, 2017, 4, 3, 1, 1, 24, 106, 7, 5, 9, 'Terintegrasinya perencanaan bidang prasarana wilayah', '0.00', ''),
(258, 2017, 4, 3, 1, 1, 24, 106, 7, 6, 10, 'Pembangunan Bidang Prasarana Wilayah yang brkelanjutan', '0.00', ''),
(259, 2017, 4, 3, 1, 1, 24, 106, 10, 3, 1, 'Dokumen Profil KPI dan Success Story WISMP II Tahun 2017', '1.00', 'Dokumen'),
(260, 2017, 4, 3, 1, 1, 24, 106, 10, 3, 2, 'Dokumen PPMU WISMP II ', '1.00', 'Dokumen'),
(261, 2017, 4, 3, 1, 1, 24, 106, 10, 4, 10, 'Terdokumentasinya kegiatan WISMP II dengan baik', '1.00', 'Dokumen'),
(262, 2017, 4, 3, 1, 1, 24, 106, 10, 5, 15, 'Tersusunnya dokumen Profil KPI dan Success Story WISMP II Tahun 2017', '0.00', ''),
(263, 2017, 4, 3, 1, 1, 24, 106, 10, 6, 16, 'Meningkatnya Pengelolaan Sumber Daya Air', '0.00', ''),
(264, 2017, 4, 3, 1, 1, 24, 106, 11, 3, 1, 'Dokumen Pelaksanaan Percepatan Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'Dokumen'),
(265, 2017, 4, 3, 1, 1, 24, 106, 11, 3, 2, 'Dokumen Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', '1.00', 'Dokumen'),
(266, 2017, 4, 3, 1, 1, 24, 106, 11, 4, 3, 'Terkoordinasinya Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', '1.00', 'Kegiatan'),
(267, 2017, 4, 3, 1, 1, 24, 106, 11, 4, 4, 'Terkoordinasi   Pelaksanaan Percepatan Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'Kegiatan'),
(268, 2017, 4, 3, 1, 1, 24, 106, 11, 5, 5, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(269, 2017, 4, 3, 1, 1, 24, 106, 11, 6, 6, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(270, 2017, 4, 3, 1, 1, 26, 403, 1, 3, 1, 'Dokumen Review RTRW Provinsi NTB', '1.00', 'Dokumen'),
(271, 2017, 4, 3, 1, 1, 26, 403, 1, 3, 2, 'Dokumen KLHS Review RTRW Provinsi NTB', '1.00', 'Dokumen'),
(272, 2017, 4, 3, 1, 1, 26, 403, 1, 3, 6, 'Dokumen Peninjauan Kembali (PK) RTRW Provinsi NTB', '1.00', 'dokumen'),
(273, 2017, 4, 3, 1, 1, 26, 403, 1, 4, 3, 'Tersedianya Dokumen Peninjauan Kembali (PK) RTRW Provinsi NTB', '1.00', 'Dokumen'),
(274, 2017, 4, 3, 1, 1, 26, 403, 1, 4, 4, 'Tersedianya dokumen KLHS Review RTRW Provinsi NTB', '1.00', 'Dokumen'),
(275, 2017, 4, 3, 1, 1, 26, 403, 1, 4, 7, 'Tersedianya Dokumen Review RTRW Provinsi NTB', '1.00', 'dokumen'),
(276, 2017, 4, 3, 1, 1, 26, 403, 1, 5, 4, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(277, 2017, 4, 3, 1, 1, 26, 403, 1, 6, 5, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(278, 2017, 4, 3, 1, 1, 26, 403, 2, 3, 1, 'Laporan pelaksanaan kegiatan BKPRD Provinsi NTB', '1.00', 'Dokumen'),
(279, 2017, 4, 3, 1, 1, 26, 403, 2, 3, 3, 'Meningkatnya Peran Badan Koordinasi Penataan Ruang Daerah (BKPRD) Provinsi NTB', '1.00', 'Tahun'),
(280, 2017, 4, 3, 1, 1, 26, 403, 2, 5, 5, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(281, 2017, 4, 3, 1, 1, 26, 403, 2, 6, 6, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(282, 2017, 4, 3, 1, 1, 27, 403, 1, 3, 1, 'Tersusunnya Pedoman Penelitian dan Pengembangan Bidang Perencanaan Pembangunan Ekonomi dan Wilayah', '1.00', 'Dokumen'),
(283, 2017, 4, 3, 1, 1, 27, 403, 1, 3, 2, 'Tersusunnya Kajian Capaian Indikator RPJMD  Bidang Perencanaan Pembangunan Ekonomi dan pengembangan wilayah', '1.00', 'Dokumen'),
(284, 2017, 4, 3, 1, 1, 27, 403, 1, 3, 3, 'Tersusunnya Master Plan Pengembangan Kawasan Strategis SAMOTA', '1.00', 'Dokumen'),
(285, 2017, 4, 3, 1, 1, 27, 403, 1, 3, 4, 'Tersusunnya Kajian Pengembangan Kelembagaan Kawasan Strategis SAMOTA', '1.00', 'Dokumen'),
(286, 2017, 4, 3, 1, 1, 27, 403, 1, 4, 5, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'kegiatan'),
(287, 2017, 4, 3, 1, 1, 27, 403, 1, 5, 6, 'Tersedianya kajian teknis dan akademis sebagai dasar penyusunan perencanaan pembangunan daerah', '0.00', ''),
(288, 2017, 4, 3, 1, 1, 27, 403, 1, 6, 7, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(289, 2017, 4, 3, 1, 1, 27, 403, 2, 3, 1, 'Tersusunnya Pedoman Penelitian dan Pengembangan Bidang Perencanaan Pembangunan Sosial', '1.00', 'Dokumen'),
(290, 2017, 4, 3, 1, 1, 27, 403, 2, 3, 2, 'Tersusunnya Kajian Profil fasilitas pelayanan dasar  di NTB', '1.00', 'Dokumen'),
(291, 2017, 4, 3, 1, 1, 27, 403, 2, 3, 3, 'Tersusunnya Kajian Upaya Minimalisasi Dampak Negatif Perkawinan Usia Dini di Pulau Lombok', '1.00', 'Dokumen'),
(292, 2017, 4, 3, 1, 1, 27, 403, 2, 3, 4, 'Tersusunnya Kajian Capaian Indikator RPJMD  Bidang  perencanaan pembangunan sosial budaya', '1.00', 'Dokumen'),
(293, 2017, 4, 3, 1, 1, 27, 403, 2, 4, 5, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'Kegiatan'),
(294, 2017, 4, 3, 1, 1, 27, 403, 2, 5, 6, 'Tersedianya kajian teknis dan akademis sebagai dasar penyusunan perencanaan pembangunan daerah', '0.00', ''),
(295, 2017, 4, 3, 1, 1, 27, 403, 2, 6, 7, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(296, 2017, 4, 3, 1, 1, 27, 403, 3, 3, 1, 'Tersusunnya Data dan Informasi Geospasial Daerah', '1.00', 'Tahun'),
(297, 2017, 4, 3, 1, 1, 27, 403, 3, 3, 2, 'Tersebarnya informasi kegiatan Bappeda', '1.00', 'Tahun'),
(298, 2017, 4, 3, 1, 1, 27, 403, 3, 4, 3, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'Kegiatan'),
(299, 2017, 4, 3, 1, 1, 27, 403, 3, 5, 4, 'Tersedianya kajian teknis dan akademis sebagai dasar penyusunan perencanaan pembangunan daerah', '0.00', ''),
(300, 2017, 4, 3, 1, 1, 27, 403, 3, 6, 5, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(301, 2017, 4, 3, 1, 1, 27, 403, 4, 3, 1, 'Terlaksananya kegiatan Dewan Riset Daerah Provinsi NTB', '1.00', 'Tahun'),
(302, 2017, 4, 3, 1, 1, 27, 403, 4, 3, 2, 'Tersebarnya informasi kegiatan Bappeda', '1.00', 'Tahun'),
(303, 2017, 4, 3, 1, 1, 27, 403, 4, 4, 3, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'Kegiatan'),
(304, 2017, 4, 3, 1, 1, 27, 403, 4, 5, 4, 'Tersedianya kajian teknis dan akademis sebagai dasar penyusunan perencanaan pembangunan daerah', '0.00', ''),
(305, 2017, 4, 3, 1, 1, 27, 403, 4, 6, 5, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `Id_Prog` smallint(6) NOT NULL,
  `Kd_Keg` smallint(6) NOT NULL,
  `Ket_Kegiatan` varchar(255) NOT NULL,
  `Lokasi` varchar(800) DEFAULT NULL,
  `Kelompok_Sasaran` varchar(255) DEFAULT NULL,
  `Status_Kegiatan` varchar(1) NOT NULL,
  `Pagu_Anggaran` decimal(15,2) DEFAULT NULL,
  `Waktu_Pelaksanaan` varchar(100) DEFAULT NULL,
  `Kd_Sumber` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kegiatan`
--

INSERT INTO `kegiatan` (`Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `Id_Prog`, `Kd_Keg`, `Ket_Kegiatan`, `Lokasi`, `Kelompok_Sasaran`, `Status_Kegiatan`, `Pagu_Anggaran`, `Waktu_Pelaksanaan`, `Kd_Sumber`) VALUES
(2017, 4, 3, 1, 1, 0, 0, 0, 'Non Kegiatan', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 1, 'Penyediaan jasa surat menyurat', 'Mataram', 'Aparatur', '2', '5850000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 2, 'Penyediaan jasa komunikasi, sumber daya air dan listrik', 'Mataram', 'Aparatur ', '2', '467900000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 7, 'Penyediaan jasa administrasi keuangan', 'Mataram', 'Aparatur ', '2', '126912000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 8, 'Penyediaan jasa kebersihan kantor', 'Mataram', 'Aparatur ', '2', '195772000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 10, 'Penyediaan alat tulis kantor', 'Mataram', 'Aparatur ', '2', '165000000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 11, 'Penyediaan barang cetakan dan penggandaan', 'Mataram', 'Aparatur ', '2', '57000000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 12, 'Penyediaan komponen instalasi listrik/penerangan bangunan kantor', 'Mataram', 'Aparatur ', '2', '19228950.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 13, 'Penyediaan peralatan dan perlengkapan kantor', 'Mataram', 'Aparatur', '2', '404335000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 17, 'Penyediaan makanan dan minuman', 'Mataram', 'Aparatur ', '2', '110000000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 18, 'Penyelarasan Program Pemerintah Pusat dan Daerah', 'Jakarta dan Provinsi Lainnya serta Luar Negeri', 'Aparatur', '2', '1171001250.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 19, 'Penyediaan jasa administrasi dan teknis perkantoran', 'Mataram', 'Aparatur', '2', '3587900000.00', '', 0),
(2017, 4, 3, 1, 1, 1, 106, 20, 'Penyelarasan Program Pemerintah Provinsi dan Kabupaten/Kota', 'se Provinsi NTB', 'Aparatur ', '2', '753150000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 5, 'pengadaan Kendaraan dinas/operasional', 'Provinsi NTB', 'Bappeda Provinsi Nusa Tenggara Barat', '2', '452150000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 22, 'Pemeliharaan rutin/berkala gedung kantor', 'Mataram', 'Aparatur ', '2', '346100000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 24, 'Pemeliharaan rutin/berkala kendaraan dinas/operasional', 'Mataram', 'Aparatur ', '2', '533670000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 26, 'Pemeliharaan rutin/berkala perlengkapan gedung kantor', 'Mataram', 'Aparatur', '2', '62500000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 30, 'Pemeliharaan rutin/berkala peralatan kantor', 'Mataram', 'Aparatur ', '2', '59500000.00', '', 0),
(2017, 4, 3, 1, 1, 2, 106, 42, 'Rehabilitasi sedang/berat gedung kantor', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 5, 106, 1, 'Pendidikan dan pelatihan formal', 'Mataram', 'Aparatur Perencana di Provinsi NTB', '2', '121400000.00', '', 0),
(2017, 4, 3, 1, 1, 5, 106, 4, 'Peningkatan mental dan fisik aparatur', 'Mataram', 'Aparatur Perencana di Provinsi NTB', '2', '26820000.00', '', 0),
(2017, 4, 3, 1, 1, 6, 106, 4, 'penyusunan pelaporan keuangan akhir tahun ', 'Mataram', 'Aparatur ', '2', '35700000.00', '', 0),
(2017, 4, 3, 1, 1, 7, 106, 1, 'Peningkatan Manajemen Asset/Barang Milik Daerah', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 105, 4, 'Penyusunan Rencana Tata Ruang Wilayah', 'Mataram', 'Aparat dan Masyarakat ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 105, 16, 'Perencanaan dan Pengendalian Pemanfaatan Ruang Daerah', 'Mataram', 'Aparat, Masyarakat dan Dunia Usaha', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 1, 'Pengumpulan, updating, dan analisis data informasi capaian target kinerja program dan kegiatan', 'Mataram', 'Aparatur ', '2', '172450000.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 4, 'Penyusunan dan analisis data/informasi perencanaan pembangunan ekonomi', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 5, 'Penyusunan profile daerah', 'Mataram', '8 Kelompok Data Profil Daerah Provinsi NTB', '2', '34450000.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 6, 'Penyusunan dan analisis data/informasi perencanaan pembangunan pemerintahan dan kesra', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 7, 'Penyusunan dan analisis data/informasi perencanaan pembangunan infrastruktur dan pengembangan wilayah', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 8, 'Peningkatan peran serta dewan riset daerah dalam perencanaan pembangunan', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 106, 9, 'Penyusunan Data Spasial', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 123, 2, 'Pengumpulan, updating dan analisis data dan statistik daerah', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 15, 123, 5, 'Pengolahan Data dan Pelayanan Informasi Daerah', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 16, 106, 3, 'Fasilitasi kerjasama dengan dunia usaha/lembaga', 'Provinsi NTB', 'Seluruh Aparatur Perencana di Provinsi NTB', '2', '566200000.00', '', 0),
(2017, 4, 3, 1, 1, 16, 106, 6, 'Pengelolaan Jaringan dan Kerjasama Informasi Geospasial', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 18, 106, 3, 'Penyusunan perencanaan pengembangan wilayah strategis dan cepat tumbuh', 'Provinsi NTB', '', '1', '67270000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 1, 'Pengembangan partisipasi masyarakat dalam perumusan program dan kebijakan layanan publik', 'Mataram', 'Aparatur ', '2', '448748000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 8, 'Penyusunan rancangan RKPD', 'Mataram', 'Aparatur ', '2', '179950000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 9, 'Penyelenggaraan musrenbang RKPD', 'Mataram', 'Aparatur perencana, masyarakat  dan dunia usaha ', '2', '618358000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 11, 'Penyusunan Laporan Kinerja Pemerintah Daerah', 'Mataram', 'Aparatur ', '2', '50125000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 12, 'Penyusunan laporan Keterangan Pertanggung Jawaban (LKPJ)', 'Mataram', 'Aparatur ', '2', '138710000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 13, 'Monitoring, evaluasi dan pelaporan', 'Mataram', 'Aparatur, masyarakat', '2', '159200000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 14, 'Penyusunan rancangan KUA dan PPAS', 'Mataram', 'Aparatur ', '2', '190000000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 15, 'Penyusunan Dokumen Perencanaan', 'Mataram', 'Aparatur ', '2', '584075000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 16, 'Publikasi Perencanaan Pembangunan Daerah', 'Mataram', 'Aparatur dan masyarakat ', '2', '108500000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 18, 'Evaluasi Dokumen Perencanaan', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 21, 'Pengembangan Sistem Informasi Perencanaan Pembangunan Daerah', 'Provinsi NTB', 'SKPD Provinsi NTB', '2', '37650000.00', '', 0),
(2017, 4, 3, 1, 1, 21, 106, 22, 'Penyelarasan Dokumen RPJMD Provinsi NTB', 'Mataram', 'Aparatur ', '2', '78350000.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 3, 'Penyusunan perencanaan pengembangan ekonomi masyarakat', 'Mataram', 'Aparatur, masyarakat dan dunia usaha', '2', '253275000.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 4, 'Penyusunan perencanaan pembangunan bidang ekonomi', 'Mataram', 'Aparatur, masyarakat dan dunia usaha', '2', '368097000.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 10, 'Sosialisasi Ketentuan di Bidang Cukai dan DBHCHT', 'Mataram', 'Aparatur dan masyarakat ', '2', '0.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 11, 'Penyusunan perencanaan pembangunan bidang investasi dan keuangan', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 12, 'Penyusunan perencanaan pembangunan bidang perindustrian, perdagangan dan pariwisata', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 22, 106, 13, 'Penyusunan perencanaan bidang pangan dan pertanian', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 23, 106, 5, 'Perencanaan Pembangunan Bidang Pemerintahan', 'Mataram', 'Meningkatnya tata kelola pemerintahan yang baik', '2', '205000000.00', '', 0),
(2017, 4, 3, 1, 1, 23, 106, 8, 'Perencanaan Pembangunan Sosial Bidang Kesra', 'Mataram', 'Aparatur ', '2', '257665000.00', '', 0),
(2017, 4, 3, 1, 1, 23, 106, 9, 'Penguatan Lembaga Mediasi', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 23, 106, 10, 'Evaluasi Aksi Daerah Pemberantasan Korupsi', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 23, 106, 11, 'Perencanaan Pembangunan Sosial Bidang Pendidikan dan Kesehatan', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 24, 106, 2, 'Penyusunan masterplan pengendalian sumber daya alam dan lingkungan hidup', 'Mataram', 'Aparatur ', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 24, 106, 7, 'Perencanaan Pembangunan Bidang Prasarana Wilayah', 'Mataram', 'Aparatur ', '2', '170580000.00', '', 0),
(2017, 4, 3, 1, 1, 24, 106, 8, 'Koordinasi Perencanaan Tata Ruang dan SDA', 'Provinsi NTB', 'SKPD Provinsi NTB', '2', '717840000.00', '', 0),
(2017, 4, 3, 1, 1, 24, 106, 10, 'Sinkronisasi dan Pengendalian Pengelolaan Irigasi Partisipatif', 'Mataram', 'Aparatur', '2', '1230482800.00', '', 0),
(2017, 4, 3, 1, 1, 24, 106, 11, 'Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 26, 403, 1, 'Penyusunan Rencana Wilayah', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 26, 403, 2, 'Peningkatan Peran Serta BKPRD dalam Perencanaan Pembangunan Wilayah', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 27, 403, 1, 'Penelitian dan pengembangan ekonomi dan wilayah', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 27, 403, 2, 'Penelitian dan pengembangan sosial budaya', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 27, 403, 3, 'Penelitian dan pengembangan informasi geospasial', '', '', '1', '0.00', '', 0),
(2017, 4, 3, 1, 1, 27, 403, 4, 'Peningkatan peran serta dewan riset daerah dalam perencanaan pembangunan', '', '', '1', '0.00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1436495090),
('m130524_201442_init', 1436495111);

-- --------------------------------------------------------

--
-- Table structure for table `monev`
--

CREATE TABLE `monev` (
  `id` int(11) NOT NULL,
  `id_indikator` int(11) NOT NULL,
  `tgl_keg` date DEFAULT NULL,
  `kinerja` varchar(500) NOT NULL,
  `permasalahan` varchar(500) DEFAULT NULL,
  `resume` varchar(500) DEFAULT NULL,
  `rekomendasi` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monev`
--

INSERT INTO `monev` (`id`, `id_indikator`, `tgl_keg`, `kinerja`, `permasalahan`, `resume`, `rekomendasi`) VALUES
(1, 4, '2018-01-10', 'Kegiatan Kinerja 1', 'Permasalahan 1', 'Resume 1', 'Rekomendasi 1');

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` text,
  `last_name` text,
  `birthdate` date DEFAULT NULL,
  `gender_id` smallint(5) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `first_name`, `last_name`, `birthdate`, `gender_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Yasrul', 'Abdullah', '1974-02-03', 1, '2015-07-30 16:21:39', '2015-07-30 16:21:39'),
(2, 3, 'Abdullah', 'Rawahah', '1979-05-16', 1, '2015-07-30 16:23:56', '2015-07-30 16:23:56'),
(3, 4, 'Fatimah', 'Sholihah', '1978-05-17', 2, '2015-07-30 16:25:15', '2015-07-30 16:25:15'),
(4, 5, 'Hamzah', 'Namira', '1980-08-27', 1, '2015-08-03 09:51:06', '2015-08-03 09:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `ID_Prog` smallint(6) NOT NULL,
  `Ket_Program` varchar(255) NOT NULL,
  `Tolak_Ukur` varchar(255) DEFAULT NULL,
  `Target_Angka` decimal(15,2) DEFAULT NULL,
  `Target_Uraian` varchar(255) DEFAULT NULL,
  `Kd_Urusan1` tinyint(4) NOT NULL,
  `Kd_Bidang1` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `ID_Prog`, `Ket_Program`, `Tolak_Ukur`, `Target_Angka`, `Target_Uraian`, `Kd_Urusan1`, `Kd_Bidang1`) VALUES
(2017, 4, 3, 1, 1, 0, 0, 'Non Program', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 1, 106, 'Program Pelayanan Administrasi Perkantoran', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 2, 106, 'Program Peningkatan Sarana dan Prasarana Aparatur ', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 5, 106, 'Program Peningkatan Kapasitas Sumber Daya Aparatur', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 6, 106, 'Program peningkatan pengembangan sistem pelaporan capaian kinerja dan keuangan', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 7, 106, 'Program Peningkatan Kapasitas Pengelolaan Keuangan Daerah', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 15, 105, 'Program Perencanaan Tata Ruang', '', '0.00', '', 1, 5),
(2017, 4, 3, 1, 1, 15, 106, 'Program pengembangan data/informasi', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 15, 123, 'Program pengembangan data/informasi/statistik daerah', '', '0.00', '', 2, 14),
(2017, 4, 3, 1, 1, 16, 106, 'Program Kerjasama Pembangunan', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 18, 106, 'Program Perencanaan Pengembangan Wilayah Strategis dan Cepat Tumbuh', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 21, 106, 'Program perencanaan pembangunan daerah', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 22, 106, 'Program perencanaan pembangunan ekonomi', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 23, 106, 'Program perencanaan sosial dan budaya', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 24, 106, 'Program perancanaan prasarana wilayah dan sumber daya alam', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 26, 403, 'Program Perencanaan Tata Ruang', '', '0.00', '', 4, 3),
(2017, 4, 3, 1, 1, 27, 403, 'Program Penelitian dan Pengembangan', '', '0.00', '', 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `realisasi`
--

CREATE TABLE `realisasi` (
  `id` int(11) NOT NULL,
  `id_indikator` int(11) NOT NULL,
  `tgl_entry` date NOT NULL,
  `fisik` decimal(5,2) NOT NULL,
  `keuangan` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `realisasi`
--

INSERT INTO `realisasi` (`id`, `id_indikator`, `tgl_entry`, `fisik`, `keuangan`) VALUES
(1, 4, '2018-01-02', '50.00', '34.00'),
(2, 4, '2018-01-25', '70.00', '60.00'),
(3, 104, '2017-11-14', '30.00', '0.00'),
(4, 2, '2018-01-09', '90.00', '78.00'),
(5, 5, '2018-01-10', '90.00', '99.00'),
(6, 6, '2018-01-15', '78.00', '78.00'),
(7, 9, '2018-01-17', '90.00', '90.00'),
(8, 13, '2018-01-24', '95.00', '95.00'),
(9, 14, '2018-01-18', '98.00', '98.00'),
(10, 1, '2018-01-09', '100.00', '98.00'),
(11, 25, '2018-01-10', '90.00', '90.00'),
(12, 10, '2018-01-18', '90.00', '90.00'),
(13, 17, '2018-01-19', '98.00', '95.00'),
(14, 65, '2018-01-16', '89.00', '87.00'),
(15, 68, '2018-01-10', '100.00', '100.00'),
(16, 92, '2018-01-18', '78.00', '67.00'),
(17, 93, '2018-01-17', '89.00', '88.00'),
(18, 126, '2018-01-17', '67.00', '56.00');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` smallint(6) NOT NULL,
  `role_name` varchar(45) NOT NULL,
  `role_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role_name`, `role_value`) VALUES
(1, 'User', 10),
(2, 'Operator', 20),
(3, 'AdminSystem', 30);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Nm_Unit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Nm_Unit`) VALUES
(1, 1, 1, 1, 'Dinas Pendidikan dan Kebudayaan'),
(2, 1, 2, 1, 'Dinas Kesehatan'),
(3, 1, 2, 2, 'Rumah Sakit Umum Daerah Provinsi'),
(4, 1, 2, 3, 'Rumah Sakit Jiwa Mutiara Sukma Provinsi'),
(5, 1, 2, 4, 'Rumah Sakit H. L. Manambai Abdul Kadir'),
(6, 1, 3, 1, 'Dinas Pekerjaan Umum dan Penataan Ruang'),
(7, 1, 4, 1, 'Dinas Perumahan dan Permukiman'),
(8, 1, 5, 1, 'Badan Kesatuan Bangsa dan Politik Dalam Negeri'),
(9, 1, 5, 2, 'Satuan Polisi Pamong Praja'),
(10, 1, 5, 3, 'Pelaksana Badan Penanggulangan Bencana Daerah Provinsi NTB'),
(11, 1, 6, 1, 'Dinas Sosial'),
(12, 2, 1, 1, 'Dinas Tenaga Kerja dan Transmigrasi'),
(13, 2, 2, 1, 'Dinas Pemberdayaan Perempuan,  Perlindungan Anak, Pengendalian Penduduk dan Keluarga Berencana'),
(14, 2, 3, 1, 'Dinas Ketahanan Pangan'),
(15, 2, 5, 1, 'Dinas Lingkungan Hidup dan Kehutanan'),
(16, 2, 7, 1, 'Dinas Pemberdayaan Masyarakat, Pemerintahan Desa, Kependudukan dan Pencatatan Sipil'),
(17, 2, 9, 1, 'Dinas Perhubungan'),
(18, 2, 10, 1, 'Dinas Komunikasi, Informatika dan Statistik'),
(19, 2, 11, 1, 'Dinas Koperasi Usaha Kecil dan Menengah'),
(20, 2, 12, 1, 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu'),
(21, 2, 13, 1, 'Dinas Pemuda dan Olahraga'),
(22, 2, 17, 1, 'Dinas Perpustakaan dan Kearsipan'),
(23, 3, 1, 1, 'Dinas Kelautan dan Perikanan'),
(24, 3, 2, 1, 'Dinas Pariwisata'),
(25, 3, 3, 1, 'Dinas Pertanian dan Perkebunan'),
(26, 3, 3, 2, 'Dinas Peternakan dan Kesehatan Hewan'),
(27, 3, 5, 1, 'Dinas Energi dan Sumber Daya Mineral'),
(28, 3, 6, 1, 'Dinas Perdagangan'),
(29, 3, 7, 1, 'Dinas Perindustrian'),
(30, 4, 1, 1, 'Dewan Perwakilan Rakyat Daerah'),
(31, 4, 1, 2, 'Kepala Daerah dan Wakil Kepala Daerah'),
(32, 4, 1, 3, 'Sekretariat Daerah'),
(33, 4, 1, 4, 'Sekretariat Dewan Perwakilan Rakyat Daerah'),
(34, 4, 1, 5, 'Badan Penghubung Daerah'),
(35, 4, 2, 1, 'Inspektorat'),
(36, 4, 3, 1, 'Badan Perencanaan Pembangunan, Penelitian dan Pengembangan Daerah'),
(37, 4, 4, 1, 'Badan Pengelolaan Keuangan dan Aset Daerah'),
(38, 4, 4, 2, 'Badan Pengelolaan Pendapatan Daerah'),
(39, 4, 5, 1, 'Badan Kepegawaian Daerah'),
(40, 4, 6, 1, 'Badan Pengembangan Sumber Daya Manusia Daerah');

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE `unit_kerja` (
  `id` smallint(6) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `id_induk` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_kerja`
--

INSERT INTO `unit_kerja` (`id`, `unit_kerja`, `id_induk`) VALUES
(1, 'Provinsi NTB', 0),
(2, 'Sekretariat Daerah', 1),
(3, 'Biro Umum', 2),
(4, 'Biro Organisasi', 2),
(5, 'Dinas Kominfotik', 1),
(6, 'Bagian Keuangan', 3),
(7, 'Bagian Rumah Tangga', 3);

-- --------------------------------------------------------

--
-- Table structure for table `urusan`
--

CREATE TABLE `urusan` (
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Nm_Urusan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `urusan`
--

INSERT INTO `urusan` (`Kd_Urusan`, `Nm_Urusan`) VALUES
(1, 'Urusan Wajib Pelayanan Dasar'),
(2, 'Urusan Wajib Bukan Pelayanan Dasar'),
(3, 'Urusan Pilihan'),
(4, 'Urusan Pemerintahan Fungsi Penunjang');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_id` smallint(6) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `status_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `unit_id`, `role_id`, `status_id`, `created_at`, `updated_at`) VALUES
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 3, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'amiruddin', 'IvGFzQ3uvJPi_P3JmqKEXdK0V9YYF7St', '$2y$13$ArWhFm0bGSl9jpZF/xIH1.hqboi..Fi0/oz59JQXnkl4OyArqWzA.', NULL, 'amir@ntbprov.go.id', 3, 4, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Administrator', 'N5yGLBNsIa7oyk35Eq3wiBfZW9cq0Ynp', '$2y$13$QjgGiHcANDFYU5bURinx0Oj3fLE7mLFp9cVyLkAc5w39Kd72IS.xu', NULL, 'yasrul@gmail.com', 5, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'abdullah', '6URjxAyu8dR9n9x_5JYnc68Im6eKhMoY', '$2y$13$xx87TaYGKgmA.ZRRSvUDEuhWtyo9Qs1NyHe4WYKl8buRmZ6v1Og3y', NULL, 'abdullah@gmail.com', 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `file_kerja`
--
ALTER TABLE `file_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `indikator`
--
ALTER TABLE `indikator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `monev`
--
ALTER TABLE `monev`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gender_id_idx` (`gender_id`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`Tahun`,`Kd_Urusan`,`Kd_Bidang`,`Kd_Unit`,`Kd_Sub`,`Kd_Prog`,`ID_Prog`);

--
-- Indexes for table `realisasi`
--
ALTER TABLE `realisasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_kerja`
--
ALTER TABLE `unit_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `file_kerja`
--
ALTER TABLE `file_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `indikator`
--
ALTER TABLE `indikator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=306;
--
-- AUTO_INCREMENT for table `monev`
--
ALTER TABLE `monev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `realisasi`
--
ALTER TABLE `realisasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `gender_id_fk` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

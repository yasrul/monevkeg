-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 06, 2018 at 05:34 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 5.6.33-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monevkeg`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_id` smallint(6) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `status_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `unit_id`, `role_id`, `status_id`, `created_at`, `updated_at`) VALUES
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 3, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'amiruddin', 'IvGFzQ3uvJPi_P3JmqKEXdK0V9YYF7St', '$2y$13$ArWhFm0bGSl9jpZF/xIH1.hqboi..Fi0/oz59JQXnkl4OyArqWzA.', NULL, 'amir@ntbprov.go.id', 3, 2, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'administrator', 'N5yGLBNsIa7oyk35Eq3wiBfZW9cq0Ynp', '$2y$13$QjgGiHcANDFYU5bURinx0Oj3fLE7mLFp9cVyLkAc5w39Kd72IS.xu', NULL, 'yasrul@gmail.com', 5, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'abdullah', '6URjxAyu8dR9n9x_5JYnc68Im6eKhMoY', '$2y$13$xx87TaYGKgmA.ZRRSvUDEuhWtyo9Qs1NyHe4WYKl8buRmZ6v1Og3y', NULL, 'abdullah@gmail.com', 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'sekretariat', '-zewkZyPamjg8zIw4wJYijM8GlNipW-M', '$2y$13$PuMO4eSDpA5fXdOlMvOx.uRBAa3c3xQ8VlpCOjuP6HSudb0faMMr6', NULL, 'sekretariat@bappeda.ntbprov.go.id', 2, 2, 1, '2018-02-26 14:40:15', '2018-02-26 14:40:57'),
(10, 'infrastruktur', 'P1f-3r4AillyyMuI0rWlQjvNBv8TjyIE', '$2y$13$gA51s5DuXHT97gJiFTkh0u7jGTs50woJ77EAWRlJKQlmexgcLw2eu', NULL, 'bappeda@ntbprov.go.id', 7, 2, 1, '2018-03-01 12:19:37', '2018-03-01 12:29:05'),
(11, 'ekonomi', 'Wsomlx2HQqExV_jwJ4OUznRlsE2SisE-', '$2y$13$hQf6ingtMFroXKO/T1L8S.eiVhNuQadpfV0SJ9xRTVyhGO2RduESW', NULL, 'ekonomi.bappeda@ntbprov.go.id', 5, 2, 1, '2018-03-01 12:20:29', '2018-03-01 12:28:36'),
(12, 'sosbud', '-giZfORbS2PpLbnWqmb_rrYlJfiJr_-9', '$2y$13$pcd003Pbh5dEX3CoroOma.fp0/OF3WIaw5nMxlMKiINrGUPWYTkC.', NULL, 'sosbud.bappeda@ntbprov.go.id', 6, 2, 1, '2018-03-01 12:21:21', '2018-03-01 12:28:10'),
(13, 'pemantauan', '3veNg4i8jDdCxU-9wYNptHmtvZjZQxKF', '$2y$13$cTVTkHeLAB5IhGhum2.ZUuAjTgeP7q4j9RgbUt3sBbALlgzj7NSba', NULL, 'pemantauan.bappeda@ntbprov.go.id', 4, 2, 1, '2018-03-01 12:22:07', '2018-03-01 12:27:48'),
(14, 'penelitian', 'bI79dwoNaMdq3dy1iGMFmvuxeDQYLRX-', '$2y$13$ojygdQmuJU8/fZQgsB1IouJmJ3XLNAJbD90M0R7lzCVw.vf7FhtkS', NULL, 'penelitian.bappeda@ntbprov.go.id', 3, 2, 1, '2018-03-01 12:22:52', '2018-03-01 12:26:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

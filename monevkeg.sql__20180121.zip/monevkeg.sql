-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2018 at 04:07 AM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 5.6.33-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monevkeg`
--

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE `bidang` (
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Nm_Bidang` varchar(255) NOT NULL,
  `Kd_Fungsi` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`Kd_Urusan`, `Kd_Bidang`, `Nm_Bidang`, `Kd_Fungsi`) VALUES
(1, 1, 'Pendidikan', 10),
(1, 2, 'Kesehatan', 7),
(1, 3, 'Pekerjaan Umum dan Penataan Ruang', 6),
(1, 4, 'Perumahan Rakyat dan Kawasan Pemukiman', 6),
(1, 5, 'Ketentraman dan Ketertiban Umum serta Perlindungan Masyarakat', 3),
(1, 6, 'Sosial', 11),
(2, 1, 'Tenaga Kerja', 4),
(2, 2, 'Pemberdayaan Perempuan dan Perlindungan Anak', 11),
(2, 3, 'Pangan', 1),
(2, 4, 'Pertanahan', 5),
(2, 5, 'Lingkungan Hidup', 5),
(2, 6, 'Administrasi Kependudukan dan Capil', 11),
(2, 7, 'Pemberdayaan Masyarakat Desa', 4),
(2, 8, 'Pengendalian Penduduk dan Keluarga Berencana', 7),
(2, 9, 'Perhubungan', 4),
(2, 10, 'Komunikasi dan Informatika', 1),
(2, 11, 'Koperasi, Usaha Kecil dan Menengah', 4),
(2, 12, 'Penanaman Modal', 4),
(2, 13, 'Kepemudaan dan Olah Raga', 10),
(2, 14, 'Statistik', 1),
(2, 15, 'Persandian', 1),
(2, 16, 'Kebudayaan', 8),
(2, 17, 'Perpustakaan', 10),
(2, 18, 'Kearsipan', 1),
(3, 1, 'Kelautan dan Perikanan', 4),
(3, 2, 'Pariwisata', 8),
(3, 3, 'Pertanian', 4),
(3, 4, 'Kehutanan', 4),
(3, 5, 'Energi dan Sumberdaya Mineral', 4),
(3, 6, 'Perdagangan', 4),
(3, 7, 'Perindustrian', 4),
(3, 8, 'Transmigrasi', 4),
(4, 1, 'Administrasi Pemerintahan', 1),
(4, 2, 'Pengawasan', 1),
(4, 3, 'Perencanaan', 1),
(4, 4, 'Keuangan', 1),
(4, 5, 'Kepegawaian', 1),
(4, 6, 'Pendidikan dan Pelatihan', 1),
(4, 7, 'Penelitian dan Pengembangan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `file_kerja`
--

CREATE TABLE `file_kerja` (
  `id` int(11) NOT NULL,
  `id_monev` int(11) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `filename_sys` varchar(255) DEFAULT NULL,
  `filename_real` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `gender_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `gender_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `indikator`
--

CREATE TABLE `indikator` (
  `id` int(11) NOT NULL,
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `ID_Prog` smallint(6) NOT NULL,
  `Kd_Keg` smallint(6) NOT NULL,
  `Kd_Indikator` tinyint(4) NOT NULL,
  `No_ID` tinyint(4) NOT NULL,
  `Tolak_Ukur` varchar(255) DEFAULT NULL,
  `Target_Angka` decimal(10,2) DEFAULT NULL,
  `Target_Uraian` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikator`
--

INSERT INTO `indikator` (`id`, `Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `ID_Prog`, `Kd_Keg`, `Kd_Indikator`, `No_ID`, `Tolak_Ukur`, `Target_Angka`, `Target_Uraian`) VALUES
(1, 2018, 4, 3, 1, 1, 1, 403, 1, 3, 1, 'Tersedianya layanan surat menyurat', '125.00', 'surat'),
(2, 2018, 4, 3, 1, 1, 1, 403, 1, 4, 2, 'Kelancaran administrasi perkantoran meningkat', '1.00', 'tahun'),
(3, 2018, 4, 3, 1, 1, 1, 403, 1, 5, 3, 'Kualitas pelayanan surat menyurat meningkat', '0.00', ''),
(4, 2018, 4, 3, 1, 1, 1, 403, 1, 6, 4, 'Tertib administrasi surat menyurat meningkat', '0.00', ''),
(5, 2018, 4, 3, 1, 1, 1, 403, 2, 3, 1, 'Jasa komunikasi, sumberdaya air, dan listrik', '1.00', 'tahun'),
(6, 2018, 4, 3, 1, 1, 1, 403, 2, 4, 2, 'Tersedianya jasa komunikasi, sumberdaya air dan listrik', '1.00', 'tahun'),
(7, 2018, 4, 3, 1, 1, 1, 403, 2, 5, 3, 'Tersedianya fasilitas penunjang pelaksanaan kegiatan', '0.00', ''),
(8, 2018, 4, 3, 1, 1, 1, 403, 2, 6, 4, 'Kelancaran tugas pokok dan fungsi setiap unit meningkat', '0.00', ''),
(9, 2018, 4, 3, 1, 1, 1, 403, 7, 3, 1, 'Tersedianya jasa administrasi keuangan', '1.00', 'tahun'),
(10, 2018, 4, 3, 1, 1, 1, 403, 7, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '1.00', 'tahun'),
(11, 2018, 4, 3, 1, 1, 1, 403, 7, 5, 3, 'Terselenggaranya pelayanan administrasi keuangan', '0.00', ''),
(12, 2018, 4, 3, 1, 1, 1, 403, 7, 6, 4, 'Tingginya penyerapan anggaran dan capaian kinerja', '0.00', ''),
(13, 2018, 4, 3, 1, 1, 1, 403, 8, 3, 1, 'Tersedianya peralatan dan bahan pembersih kantor', '100.00', '%'),
(14, 2018, 4, 3, 1, 1, 1, 403, 8, 4, 2, 'Terciptanya lingkungan kerja yang sehat dan nyaman', '100.00', '%'),
(15, 2018, 4, 3, 1, 1, 1, 403, 8, 5, 3, 'Iklim kerja aparatur yang baik', '0.00', ''),
(16, 2018, 4, 3, 1, 1, 1, 403, 8, 6, 4, 'Kehadiran kerja aparatur ditempat kerja meningkat', '0.00', ''),
(17, 2018, 4, 3, 1, 1, 1, 403, 10, 3, 1, 'Tersedianya kebutuhan alat tulis kantor', '1.00', 'tahun'),
(18, 2018, 4, 3, 1, 1, 1, 403, 10, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(19, 2018, 4, 3, 1, 1, 1, 403, 10, 5, 3, 'Kualitas pelaksanaan kegiatan administrasi perkantoran meningkat', '0.00', ''),
(20, 2018, 4, 3, 1, 1, 1, 403, 10, 6, 4, 'produktivitas kerja meningkat', '0.00', ''),
(21, 2018, 4, 3, 1, 1, 1, 403, 11, 3, 1, 'Tersedianya barang cetakan dan penggandaan', '1.00', 'tahun'),
(22, 2018, 4, 3, 1, 1, 1, 403, 11, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(23, 2018, 4, 3, 1, 1, 1, 403, 11, 5, 3, 'Kualitas pelaksanaan kegiatan aadministrasi perkantoran meningkat', '0.00', ''),
(24, 2018, 4, 3, 1, 1, 1, 403, 11, 6, 4, 'Produktivitas kerja meningkat', '0.00', ''),
(25, 2018, 4, 3, 1, 1, 1, 403, 12, 3, 1, 'Tersedianya komponen instalasi listrik dan penerangan listrik bangunan kantor', '1.00', ' Unit Gedung Kantor'),
(26, 2018, 4, 3, 1, 1, 1, 403, 12, 4, 2, 'Terfasilitasinya sumber penerangan dan peralatan listrik gedung kantor', '1.00', ' Unit Gedung Kantor'),
(27, 2018, 4, 3, 1, 1, 1, 403, 12, 5, 3, 'Pelaksanaan pekerjaan perkantoran berjalan dengan baik', '0.00', ''),
(28, 2018, 4, 3, 1, 1, 1, 403, 12, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(29, 2018, 4, 3, 1, 1, 1, 403, 13, 3, 1, 'Tersedianya peralatan dan perlengkapan kantor', '36.00', 'unit/buah/paket'),
(30, 2018, 4, 3, 1, 1, 1, 403, 13, 4, 2, 'Meningkatnya Pelayanan Administrasi Perkantoran', '100.00', '%'),
(31, 2018, 4, 3, 1, 1, 1, 403, 13, 5, 3, 'Pelaksanaan pekerjaan perkantoran berjalan dengan baik', '0.00', ''),
(32, 2018, 4, 3, 1, 1, 1, 403, 13, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(33, 2018, 4, 3, 1, 1, 1, 403, 17, 3, 1, 'Tersedianya makanan dan minuman', '1.00', 'tahun'),
(34, 2018, 4, 3, 1, 1, 1, 403, 17, 4, 2, 'Kelancaran administrasi perkantoran meningkat', '100.00', '%'),
(35, 2018, 4, 3, 1, 1, 1, 403, 17, 5, 3, 'Lancarnya pelaksanaan rapat koordinasi/konsultasi', '0.00', ''),
(36, 2018, 4, 3, 1, 1, 1, 403, 17, 6, 4, 'Meningkatnya pelayanan rapat koordinasi/konsultasi', '0.00', ''),
(37, 2018, 4, 3, 1, 1, 1, 403, 18, 3, 1, 'Terlaksananya rapat koordinasi dan konsultasi ke luar daerah', '75.00', 'kali'),
(38, 2018, 4, 3, 1, 1, 1, 403, 18, 4, 2, 'Dokumen kebijakan strategis', '1.00', 'dokumen'),
(39, 2018, 4, 3, 1, 1, 1, 403, 18, 5, 3, 'Dukungan pelaksanaan perencanaan pembangunan daerah secara nasional', '0.00', ''),
(40, 2018, 4, 3, 1, 1, 1, 403, 18, 6, 4, 'Selarasnya perencanaan pembangunan daerah dengan perencanaan pembangunan nasional', '0.00', ''),
(41, 2018, 4, 3, 1, 1, 1, 403, 19, 3, 1, 'Tersedianya jasa administrasi teknis perkantoran', '126.00', 'orang'),
(42, 2018, 4, 3, 1, 1, 1, 403, 19, 4, 2, 'Meningkatnya kelancaran administrasi perkantoran', '100.00', '%'),
(43, 2018, 4, 3, 1, 1, 1, 403, 19, 5, 3, 'Pelayanan aurusan administrasi dan teknis perkantoran yang cepat dan efisien', '0.00', ''),
(44, 2018, 4, 3, 1, 1, 1, 403, 19, 6, 4, 'Meningkatnya kualitas layanan administrasi umun', '0.00', ''),
(45, 2018, 4, 3, 1, 1, 1, 403, 20, 3, 1, 'Terlaksananya rapat koordinasi dengan kabupaten/kota', '68.00', 'kali'),
(46, 2018, 4, 3, 1, 1, 1, 403, 20, 4, 2, 'Dokumen kebijakan strategis', '1.00', 'dokumen'),
(47, 2018, 4, 3, 1, 1, 1, 403, 20, 5, 3, 'Dukungan pelaksanaan perencanaan pembangunan skala regional', '0.00', ''),
(48, 2018, 4, 3, 1, 1, 1, 403, 20, 6, 4, 'Selarasnya perencanaan pembangunan provinsi dengan perencanaan pembangunan kabupaten/kota', '0.00', ''),
(49, 2018, 4, 3, 1, 1, 2, 403, 22, 3, 1, 'Terpeliharanya gedung kantor secara rutin dan berkala', '1.00', 'Unit Gedung Kantor'),
(50, 2018, 4, 3, 1, 1, 2, 403, 22, 4, 2, 'Umur fungsional gedung kantor meningkat', '1.00', 'Unit Gedung Kantor'),
(51, 2018, 4, 3, 1, 1, 2, 403, 22, 5, 3, 'Umur fungsional gedung kantor meningkat', '0.00', ''),
(52, 2018, 4, 3, 1, 1, 2, 403, 22, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(53, 2018, 4, 3, 1, 1, 2, 403, 24, 3, 1, 'Terpeliharanya secara rutin dan berkala kendaraan dinas/operasional', '76.00', 'unit'),
(54, 2018, 4, 3, 1, 1, 2, 403, 24, 4, 2, 'Umur fungsional kendaraan dinas/operasional meningkat', '76.00', 'unit'),
(55, 2018, 4, 3, 1, 1, 2, 403, 24, 5, 3, 'Tingkat kelancaran pelaksanaan tugas meningkat/tahun', '0.00', ''),
(56, 2018, 4, 3, 1, 1, 2, 403, 24, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(57, 2018, 4, 3, 1, 1, 2, 403, 26, 3, 1, 'Terpeliharanya secara rutin/berkala perlengkapan gedung kantor', '75.00', 'unit'),
(58, 2018, 4, 3, 1, 1, 2, 403, 26, 4, 2, 'Umur fungsional perlengkapan gedung kantor meningkat/tahun', '75.00', 'unit'),
(59, 2018, 4, 3, 1, 1, 2, 403, 26, 5, 3, 'Tingkat kelancaran pelaksanaan tugas meningkat', '0.00', ''),
(60, 2018, 4, 3, 1, 1, 2, 403, 26, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(61, 2018, 4, 3, 1, 1, 2, 403, 30, 3, 1, 'Terpeliharanya secara rutin/berkala peralatan kantor', '184.00', 'unit'),
(62, 2018, 4, 3, 1, 1, 2, 403, 30, 4, 2, 'Umur fungsional peralatan kantor meningkat/tahun', '184.00', 'unit'),
(63, 2018, 4, 3, 1, 1, 2, 403, 30, 5, 3, 'Tingkat kelancaran pelaksnaan tugas meningkat', '0.00', ''),
(64, 2018, 4, 3, 1, 1, 2, 403, 30, 6, 4, 'Produktifitas kerja meningkat', '0.00', ''),
(65, 2018, 4, 3, 1, 1, 2, 403, 42, 3, 1, 'Terpeliharanya gedung kantor', '1.00', 'unit gedung kantor'),
(66, 2018, 4, 3, 1, 1, 5, 403, 1, 3, 1, 'Terselenggaranya rapat koordinasi Jabatan Fungsional Perencana (JFP)', '2.00', 'kali'),
(67, 2018, 4, 3, 1, 1, 5, 403, 1, 3, 2, 'Terselenggaranya pelatihan peningkatan kapasitas Fungsional Perencana NTB', '1.00', 'kali'),
(68, 2018, 4, 3, 1, 1, 5, 403, 1, 3, 3, 'Terselenggaranya pendidikan dan pelatihan formal bagi aparatur', '10.00', 'orang'),
(69, 2018, 4, 3, 1, 1, 5, 403, 1, 4, 4, 'Meningkatnya pemahaman peserta rapat koordinasi tentang Jabatan Fungsional Perencana (JFP)', '50.00', 'orang'),
(70, 2018, 4, 3, 1, 1, 5, 403, 1, 4, 5, 'Meningkatnya kapasitas aparatur Jabatan Fungsional Perencana (JFP)', '75.00', 'orang'),
(71, 2018, 4, 3, 1, 1, 5, 403, 1, 4, 6, 'Meningkatnya kemampuan intelektual aparatur yang mengikuti pendidikan dan pelatihan formal', '10.00', 'orang'),
(72, 2018, 4, 3, 1, 1, 5, 403, 1, 5, 7, 'Kemapuan dalam melaksanakan tugas meningkat', '0.00', ''),
(73, 2018, 4, 3, 1, 1, 5, 403, 1, 6, 8, 'Hasil kerja atau prestasi kerja meningkat', '0.00', ''),
(74, 2018, 4, 3, 1, 1, 5, 403, 4, 3, 1, 'Terbinanya mental dan fisik aparatur', '126.00', 'orang'),
(75, 2018, 4, 3, 1, 1, 5, 403, 4, 4, 2, 'Terbinanya mental dan fisik aparatur meningkat', '126.00', 'orang'),
(76, 2018, 4, 3, 1, 1, 5, 403, 4, 5, 3, 'Gairah kerja meningkat', '0.00', ''),
(77, 2018, 4, 3, 1, 1, 5, 403, 4, 6, 4, 'Produktifitas berfikir dan keberja meningkat', '0.00', ''),
(78, 2018, 4, 3, 1, 1, 6, 403, 4, 3, 1, 'Buku Laporan Keuangan Semesteran Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(79, 2018, 4, 3, 1, 1, 6, 403, 4, 3, 2, 'Buku laporan keuangan akhir tahun', '1.00', 'dokumen'),
(80, 2018, 4, 3, 1, 1, 6, 403, 4, 4, 3, 'Tersusunnya  laporan keuangan semesteran Bappeda provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(81, 2018, 4, 3, 1, 1, 6, 403, 4, 4, 4, 'Tersusunnya  laporan keuangan akhir tahun Bappeda provinsi NTB Tahun 2016', '1.00', 'dokumen'),
(82, 2018, 4, 3, 1, 1, 6, 403, 4, 5, 5, 'Tersedianya media pertanggungjawaban Bappeda yang akuntable', '0.00', ''),
(83, 2018, 4, 3, 1, 1, 6, 403, 4, 6, 6, 'Tersedianya laporan pertanggungjawaban keuangan Bappeda Provinsi NTB', '0.00', ''),
(84, 2018, 4, 3, 1, 1, 7, 403, 1, 3, 1, 'Buku Laporan Aset tahun Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(85, 2018, 4, 3, 1, 1, 7, 403, 1, 4, 2, 'Tersusunnya Laporan Aset tahun Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(86, 2018, 4, 3, 1, 1, 7, 403, 1, 5, 3, 'Tertib administrasi pengelolaan aset/barang milik daerah meningkat', '0.00', ''),
(87, 2018, 4, 3, 1, 1, 7, 403, 1, 6, 4, 'Efektifitas penggunaan aset/barang milik daerah meningkat', '0.00', ''),
(88, 2018, 4, 3, 1, 1, 15, 403, 1, 3, 1, 'Data Sistim Informasi Pembangunan Daerah Provinsi NTB Tahun 2018 dan Dokumen PPID Bappeda Provinsi NTB tahun 2018', '2.00', 'dokumen'),
(89, 2018, 4, 3, 1, 1, 15, 403, 1, 4, 2, 'Tersusunnya Data Sistim Informasi Pembangunan Daerah Provinsi NTB Tahun 2018 dan Dokumen PPID Bappeda Provinsi NTB tahun 2018', '2.00', 'dokumen'),
(90, 2018, 4, 3, 1, 1, 15, 403, 1, 5, 3, 'Tersedianya Data Sistim Informasi Pembangunan Daerah Provinsi NTB Tahun 2018 dan Dokumen PPID Bappeda Provinsi NTB tahun 2018', '0.00', ''),
(91, 2018, 4, 3, 1, 1, 15, 403, 1, 6, 4, 'Meningkatnya kualitas Perencanaan Pembangunan Daerah', '0.00', ''),
(92, 2018, 4, 3, 1, 1, 15, 403, 9, 3, 1, 'Penyusunan Peta Sebaran Investasi', '1.00', 'dokumen'),
(93, 2018, 4, 3, 1, 1, 15, 403, 9, 3, 2, 'Penyusunan Peta Sebaran UMKM di Pulau Lombok', '1.00', 'dokumen'),
(94, 2018, 4, 3, 1, 1, 15, 403, 9, 3, 3, 'Apdeting Peta Infrastruktur Jalan dan Jembatan Provinsi NTB', '1.00', 'dokumen'),
(95, 2018, 4, 3, 1, 1, 15, 403, 9, 3, 4, 'Penyusunan Peta Jaringan Irigasi Pulau Lombok ', '1.00', 'dokumen'),
(96, 2018, 4, 3, 1, 1, 15, 403, 9, 3, 5, 'Penyusunan Peraturan Gubernur', '1.00', 'dokumen'),
(97, 2018, 4, 3, 1, 1, 15, 403, 9, 4, 6, 'Tersusunya Peta Sebaran Investasi, Tersusunya Peta Sebaran UMKM di Pulau Lombok,  Peta Infrastruktur Jalan dan Jembatan Provinsi NTB, Tersusunya Peta Jaringan Irigasi Pulau Lombok ,  Tersusunnya Peraturan Gubernur NTB Satu Peta', '5.00', 'dokumen'),
(98, 2018, 4, 3, 1, 1, 15, 403, 9, 5, 7, 'Tersedianya Data Pembangunan Provinsi NTB', '0.00', ''),
(99, 2018, 4, 3, 1, 1, 15, 403, 9, 6, 8, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(100, 2018, 4, 3, 1, 1, 21, 403, 1, 3, 1, 'Laporan Kegiatan Pra Forum SKPD Provinsi NTB Tahun 2018', '1.00', 'dokumen'),
(101, 2018, 4, 3, 1, 1, 21, 403, 1, 3, 2, 'Laporan pelaksanaan Forum SKPD Provinsi NTB Tahun 2018', '1.00', 'dokumen'),
(102, 2018, 4, 3, 1, 1, 21, 403, 1, 3, 3, 'Laporan Kegiatan  Sarasehan Pembangunan NTB Tahun 2019', '1.00', 'dokumen'),
(103, 2018, 4, 3, 1, 1, 21, 403, 1, 3, 4, 'Laporan Rapat Kerja  Bappeda se Provinsi NTB Tahun 2018', '1.00', 'dokumen'),
(104, 2018, 4, 3, 1, 1, 21, 403, 1, 4, 5, 'Terselenggaranya tahapan/proses Perencanaan Pembangunan Daerah Tahun 2018', '1.00', 'kegiatan'),
(105, 2018, 4, 3, 1, 1, 21, 403, 1, 5, 6, 'Peningkatan sinkronisasi rencana kerja', '0.00', ''),
(106, 2018, 4, 3, 1, 1, 21, 403, 1, 6, 7, 'Selarasnya rencana program pembangunan daerah', '0.00', ''),
(107, 2018, 4, 3, 1, 1, 21, 403, 5, 3, 1, 'Dokumen Sinkronisasi RPJMD Provinsi NTB dengan RPJMD Kab/Kota', '1.00', 'dokumen'),
(108, 2018, 4, 3, 1, 1, 21, 403, 5, 4, 2, 'RPJMD Provinsi yang selaras dengan RPJMD Kab/Kota', '1.00', 'dokumen'),
(109, 2018, 4, 3, 1, 1, 21, 403, 5, 5, 3, 'perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(110, 2018, 4, 3, 1, 1, 21, 403, 5, 5, 4, 'Sistem perencanaan pembangunan yang selaras dan efektif', '0.00', ''),
(111, 2018, 4, 3, 1, 1, 21, 403, 8, 3, 1, 'Tersusunnya Dokumen RKPD Perubahan Prov. NTB TA 2018', '1.00', 'dokumen'),
(112, 2018, 4, 3, 1, 1, 21, 403, 8, 3, 2, 'Tersusunnya Dokumen RKPD Provinsi NTB Tahun 2019', '1.00', 'dokumen'),
(113, 2018, 4, 3, 1, 1, 21, 403, 8, 4, 3, 'Dokumen RKPD Perubahan Provinsi NTB TA 2018 dan RKPD TA 2019', '2.00', 'dokumen'),
(114, 2018, 4, 3, 1, 1, 21, 403, 8, 5, 4, 'Perencanaan Pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(115, 2018, 4, 3, 1, 1, 21, 403, 8, 6, 5, 'Pembangunan Tahunan Yang Terarah, Efektif dan efisien', '0.00', ''),
(116, 2018, 4, 3, 1, 1, 21, 403, 9, 3, 1, 'Dokumen Perencanaan Pembangunan Daerah Tahun 2019', '1.00', 'dokumen'),
(117, 2018, 4, 3, 1, 1, 21, 403, 9, 4, 2, 'Terselenggaranya kegiatan Pra Musrenbang dan Musrenbang RKPD Provinsi NTB', '1.00', 'kegiatan'),
(118, 2018, 4, 3, 1, 1, 21, 403, 9, 5, 3, 'Meningkatnya peran masyarakat dalam proses perencanaan pembangunan', '0.00', ''),
(119, 2018, 4, 3, 1, 1, 21, 403, 9, 6, 4, 'Sistem perencanaan pembangunan daerah yang selaras dan efektif', '0.00', ''),
(120, 2018, 4, 3, 1, 1, 21, 403, 11, 3, 1, 'Laporan Kinerja Instansi Pemerintah (LKjIP) Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(121, 2018, 4, 3, 1, 1, 21, 403, 11, 4, 2, 'Tersusunnya Laporan Kinerja Instansi Pemerintah (LKjIP) Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(122, 2018, 4, 3, 1, 1, 21, 403, 11, 5, 3, 'Tersedianya media pertanggungjawaban Bappeda yang akuntable', '0.00', ''),
(123, 2018, 4, 3, 1, 1, 21, 403, 11, 6, 4, 'Meningkatnya akuntabilitas dan kredibilitas hasil pelaksanaan kegiatan Bappeda', '0.00', ''),
(124, 2018, 4, 3, 1, 1, 21, 403, 12, 3, 1, 'Dokumen laporan LKPJ Akhir Masa Jabatan (AMJ) Gubernur NTB Tahun 2013-2017', '1.00', 'dokumen'),
(125, 2018, 4, 3, 1, 1, 21, 403, 12, 3, 2, 'Dokumen Laporan LKPJ Gubernur Tahun 2017', '1.00', 'dokumen'),
(126, 2018, 4, 3, 1, 1, 21, 403, 12, 4, 3, 'Terinformasikannya capaian kinerja pelaksaan program pembangunan daerah yang akuntabel', '100.00', '%'),
(127, 2018, 4, 3, 1, 1, 21, 403, 12, 5, 4, 'Meningkatnya kualitas perencanaan dan pelaksanaan pembangunan', '0.00', ''),
(128, 2018, 4, 3, 1, 1, 21, 403, 12, 6, 5, 'Pertanggungjawaban yang akuntabel', '0.00', ''),
(129, 2018, 4, 3, 1, 1, 21, 403, 13, 3, 1, 'Dokumen Evaluasi Program Prioritas RPJMD Provinsi NTB Semester I dan Semester II TA. 2018', '2.00', 'dokumen'),
(130, 2018, 4, 3, 1, 1, 21, 403, 13, 3, 2, 'Dokumen Evaluasi Triwulanan APBN Triwulan IV TA. 2017 dan Triwulan I, II dan III TA. 2018', '4.00', 'dokumen'),
(131, 2018, 4, 3, 1, 1, 21, 403, 13, 3, 3, 'Dokumen sinkronisasi Program Kegiatan APBN dengan APBD TA. 2018', '1.00', 'dokumen'),
(132, 2018, 4, 3, 1, 1, 21, 403, 13, 3, 4, 'Dokumen Evaluasi RKPD SKPD Provinsi dan Kabupaten/Kota Triwulan IV TA. 2017 dan Triwulan I, II, III TA. 2018', '4.00', 'dokumen'),
(133, 2018, 4, 3, 1, 1, 21, 403, 13, 4, 5, 'Terevaluasinya dan terpantaunya program/kegiatan pembangunan daerah', '0.00', 'SKPD lingkup Provinsi NTB'),
(134, 2018, 4, 3, 1, 1, 21, 403, 13, 5, 6, 'Perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(135, 2018, 4, 3, 1, 1, 21, 403, 13, 6, 7, 'Perencanaan pembangunan yang tepat sasaran', '0.00', ''),
(136, 2018, 4, 3, 1, 1, 21, 403, 14, 3, 1, 'Dokumen Evaluasi Program Prioritas RPJMD Provinsi NTB Semester I  dan Semester II TA. 2018', '2.00', 'dokumen'),
(137, 2018, 4, 3, 1, 1, 21, 403, 14, 3, 2, 'Dokumen Evaluasi Triwulanan APBN Triwulan IV TA. 2017dan Triwulan I, II dan III TA. 2018', '4.00', 'dokumen'),
(138, 2018, 4, 3, 1, 1, 21, 403, 14, 3, 3, 'Dokumen Sinkronisasi Program Kegiatan APBN dengan APBD Tahun Anggaran 2018', '1.00', 'dokumen'),
(139, 2018, 4, 3, 1, 1, 21, 403, 14, 3, 4, 'Dokumen Evaluasi RKPD SKPD Provinsi dan Kabupaten/Kota Triwulan IV TA 2017 dan Triwulan I, II, III TA2018', '4.00', 'dokumen'),
(140, 2018, 4, 3, 1, 1, 21, 403, 14, 3, 5, 'Dokumen Ensiklopedia Kinerja Pembangunan Provinsi NTB', '5.00', 'dokumen'),
(141, 2018, 4, 3, 1, 1, 21, 403, 14, 4, 6, 'Terevaluasinya dan terpantaunya program/kegiatan pembangunan daerah', '0.00', 'SKPD lingkup Provinsi NTB'),
(142, 2018, 4, 3, 1, 1, 21, 403, 14, 5, 7, 'Perencanaan pembangunan yang tepat sasaran', '0.00', ''),
(143, 2018, 4, 3, 1, 1, 21, 403, 14, 6, 8, 'SKPD Lingkup Provinsi NTB dan Kabupaten / Kota.', '0.00', ''),
(144, 2018, 4, 3, 1, 1, 21, 403, 15, 3, 1, 'Dokumen Rencana Kerja (Renja) Perubahan Bappeda Provinsi NTB Tahun 2018, dan Renja Bappeda Provinsi NTB Tahun 2019', '2.00', 'dokumen'),
(145, 2018, 4, 3, 1, 1, 21, 403, 15, 3, 2, 'Rencana Kerja Anggaran (RKA) Perubahan Bappeda Provinsi NTB Tahun Anggaran 2018 dan RKA Bappeda Provinsi NTB Tahun 2019', '2.00', 'dokumen'),
(146, 2018, 4, 3, 1, 1, 21, 403, 15, 3, 3, 'Laporan Tahunan Pelaksanaan Program dan Kegiatan Bappeda Provinsi NTB Tahun 2017', '1.00', 'dokumen'),
(147, 2018, 4, 3, 1, 1, 21, 403, 15, 3, 4, 'Laporan Capaian Rencana Aksi Indikator Kinerja Bappeda', '1.00', 'dokumen'),
(148, 2018, 4, 3, 1, 1, 21, 403, 15, 3, 5, 'Terlaksananya pembahasan/asistensi  Pra RKA Perubahan SKPD Lingkup Pemerintah Provinsi NTB TA. 2017 dan pembahasan/asistensi  Pra RKA SKPD Lingkup Pemerintah Provinsi NTB TA. 2019', '2.00', 'kegiatan'),
(149, 2018, 4, 3, 1, 1, 21, 403, 15, 4, 6, 'Tersusunnya Dokumen Perencanaan Pembangunan Tahun 2017', '6.00', 'dokumen'),
(150, 2018, 4, 3, 1, 1, 21, 403, 15, 5, 7, 'Tersedianya dokumen-dokumen perencanaan pembangunan daerah', '0.00', ''),
(151, 2018, 4, 3, 1, 1, 21, 403, 16, 3, 1, 'Terselenggaranya sosialisasi/publikasi hasil perencanaan pembangunan daerah', '1.00', 'tahun'),
(152, 2018, 4, 3, 1, 1, 21, 403, 16, 4, 2, 'Tersosialisasinya/terpublikasinya hasil perencanaan pembangunan daerah', '1.00', 'tahun'),
(153, 2018, 4, 3, 1, 1, 21, 403, 16, 5, 3, 'Pengetahuan masyarakat tentang hasil perencanaan pembangunan daerah meningkat', '0.00', ''),
(154, 2018, 4, 3, 1, 1, 21, 403, 16, 6, 4, 'Masyarakat berupaya berpartisipasi dalam perencanaan pembangunan', '0.00', ''),
(155, 2018, 4, 3, 1, 1, 21, 403, 18, 3, 1, 'Tersusunnya Dokumen RKPD Perubahan Prov. NTB TA 2018', '1.00', 'dokumen'),
(156, 2018, 4, 3, 1, 1, 21, 403, 18, 3, 2, 'Tersusunnya Dokumen RKPD Provinsi NTB Tahun 2019', '1.00', 'dokumen'),
(157, 2018, 4, 3, 1, 1, 21, 403, 18, 4, 3, 'Dokumen RKPD Perubahan Provinsi NTB TA 2018 dan RKPD TA 2019', '2.00', 'dokumen'),
(158, 2018, 4, 3, 1, 1, 21, 403, 18, 5, 4, 'Perencanaan Pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(159, 2018, 4, 3, 1, 1, 21, 403, 18, 6, 5, 'Pembangunan Tahunan Yang Terarah, Efektif dan efisien', '0.00', ''),
(160, 2018, 4, 3, 1, 1, 21, 403, 21, 3, 1, 'Aplikasi e-Planning (e-RPJMD, e-Renstra, e-Musrenbang, e-Renja OPD, e-Aspirasi DPRD, e-Monev, e-RKPD, e-KUA-PPAS, e-ASB)', '9.00', 'aplikasi'),
(161, 2018, 4, 3, 1, 1, 21, 403, 21, 4, 2, 'Aplikasi e-Planning', '9.00', 'aplikasi'),
(162, 2018, 4, 3, 1, 1, 21, 403, 21, 5, 3, 'Perencanaan Pembangunan Berbasis Elektronik', '0.00', ''),
(163, 2018, 4, 3, 1, 1, 21, 403, 21, 6, 4, 'Sistem Perencanaan Pembangunan yang selaras dan efektif', '0.00', ''),
(164, 2018, 4, 3, 1, 1, 21, 403, 22, 3, 1, 'Dokumen Sinkronisasi RPJMD Provinsi NTB dengan RPJMD Kab/Kota', '1.00', 'dokumen'),
(165, 2018, 4, 3, 1, 1, 21, 403, 22, 4, 2, 'RPJMD Provinsi yang selaras dengan RPJMD Kab/Kota', '1.00', 'dokumen'),
(166, 2018, 4, 3, 1, 1, 21, 403, 22, 5, 3, 'perencanaan pembangunan yang tepat waktu dan tepat sasaran', '0.00', ''),
(167, 2018, 4, 3, 1, 1, 21, 403, 22, 6, 4, 'Sistem perencanaan pembangunan yang selaras dan efektif', '0.00', ''),
(168, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 1, 'Dokumen Pelaksanaan Kegiatan DBH CHT Provinsi NTB Tahun 2014 s.d. 2017', '1.00', 'dokumen'),
(169, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 2, 'Dokumen Pelaksanaan Kegiatan DBH CHT Provinsi NTB Semester I TA. 2018', '1.00', 'dokumen'),
(170, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 3, 'Laporan Pelaksanaan Kegiatan Rekonsiliasi DBH CHT', '1.00', 'dokumen'),
(171, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 4, 'Laporan Pelaksanaan Rapat Koordinasi DBH CHT', '1.00', 'dokumen'),
(172, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 5, 'Laporan Evaluasi Pelaksanaan Kegiatan DBH CHT Prov. NTB TA. 2017', '1.00', 'dokumen'),
(173, 2018, 4, 3, 1, 1, 22, 403, 10, 3, 6, 'Laporan Evaluasi Pelaksanaan Kegiatan DBH CHT Prov. NTB Semester I TA. 2018', '1.00', 'dokumen'),
(174, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 7, 'Tersusunnya Dokumen Pelaksanaan Kegiatan DBH CHT Provinsi NTB Tahun 2014 s.d. 2017', '1.00', 'dokumen'),
(175, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 8, 'Tersusunnya Dokumen Pelaksanaan Kegiatan DBH CHT Provinsi NTB Semester I TA. 2018', '1.00', 'dokumen'),
(176, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 9, 'Terlaksananya Rekonsiliasi DBH CHT Provinsi NTB', '1.00', 'kegiatan'),
(177, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 10, 'Terlaksananya Rapat Koordinasi DBH CHT', '1.00', 'kegiatan'),
(178, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 11, 'Terlaksananya Evaluasi Pelaksanaan Kegiatan DBH CHT Prov. NTB TA. 2017', '1.00', 'kegiatan'),
(179, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 12, 'Terlaksananya Evaluasi Pelaksanaan Kegiatan DBH CHT Prov. NTB Semester I TA. 2018', '1.00', 'kegiatan'),
(180, 2018, 4, 3, 1, 1, 22, 403, 10, 4, 13, 'Terlaksananya Monitoring dan Evaluasi ketentuan di bidang cukai', '1.00', 'kegiatan'),
(181, 2018, 4, 3, 1, 1, 22, 403, 10, 5, 14, 'Dokumen perencanaan kegiatan DBH CHT Provinsi NTB', '0.00', ''),
(182, 2018, 4, 3, 1, 1, 22, 403, 10, 6, 15, 'Tersedianya data dan informasi tentang program/kegiatan DBHCHT di NTB', '0.00', ''),
(183, 2018, 4, 3, 1, 1, 22, 403, 11, 3, 1, 'Dokumen Rencana Aksi Daerah (RAD), Data Base dan Laporan Tahunan SDGs di Provinsi NTB', '3.00', 'dokumen'),
(184, 2018, 4, 3, 1, 1, 22, 403, 11, 4, 2, 'Tersusunnya Dokumen SDGs Provinsi NTB (Rencana Aksi Daerah, Data Base dan Laporan Tahunan)', '3.00', 'dokumen'),
(185, 2018, 4, 3, 1, 1, 22, 403, 11, 5, 3, 'Dokumen Perencanaan Pembangunan Ekonomi sebagai salah satu acuan dalam pelaksanaan program/kegiatan bidang ekonomi', '0.00', ''),
(186, 2018, 4, 3, 1, 1, 22, 403, 11, 6, 4, 'Penyempurnaan terhadap dokumen perencanaan pembangunan bidang ekonomi', '0.00', ''),
(187, 2018, 4, 3, 1, 1, 22, 403, 12, 3, 1, 'Dokumen Pelaksanaan KEK Provinsi NTB (SEM I, SEM II dan Laporan Akhir)', '1.00', 'dokumen'),
(188, 2018, 4, 3, 1, 1, 22, 403, 12, 4, 2, 'Tersusunnya Dokumen Pelaksanaan KEK Provinsi NTB (SEM I, SEM II dan Laporan Akhir)', '1.00', 'dokumen'),
(189, 2018, 4, 3, 1, 1, 22, 403, 12, 5, 3, 'Laporan pelaksanaan KEK Provinsi NTB Semester I, Semester II dan Laporan Akhir sebagai pertanggungjawaban atas pelaksanaan kegiatan Sekretariat Dewan KEK Provinsi NTB', '0.00', ''),
(190, 2018, 4, 3, 1, 1, 22, 403, 12, 6, 4, 'Akuntabilitas kinerja yang akuratif', '0.00', ''),
(191, 2018, 4, 3, 1, 1, 22, 403, 13, 3, 1, 'Dokumen Laporan Pelaksanaan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'dokumen'),
(192, 2018, 4, 3, 1, 1, 22, 403, 13, 3, 2, 'Dokumen Strategi Penanggulangan Kemiskinan Daerah Provinsi NTB Tahun 2018 s.d. 2023', '1.00', 'dokumen'),
(193, 2018, 4, 3, 1, 1, 22, 403, 13, 3, 3, 'Dokumen Laporan Hasil Pelaksanaan Rapat Koordinasi Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'dokumen'),
(194, 2018, 4, 3, 1, 1, 22, 403, 13, 3, 4, 'Dokumen Laporan Hasil Pelaksanaan Ratek Penanggulangan Kemiskinan', '2.00', 'dokumen'),
(195, 2018, 4, 3, 1, 1, 22, 403, 13, 3, 5, 'Dokumen Laporan Hasil Pelaksanaan Bimtek Penajaman Analisis Belanja Publik Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'dokumen'),
(196, 2018, 4, 3, 1, 1, 22, 403, 13, 4, 6, 'Tersusunnya Dokumen Laporan Pelaksanaan Penanggulangan Kemiskinan Daerah (LP2KD) Provinsi NTB', '1.00', 'dokumen'),
(197, 2018, 4, 3, 1, 1, 22, 403, 13, 4, 7, 'Tersusunnya Dokumen Strategi Penanggulangan Kemiskinan Daerah (SPKD) Provinsi NTB Tahun 2018 s.d. 2023', '1.00', 'dokumen'),
(198, 2018, 4, 3, 1, 1, 22, 403, 13, 4, 8, 'Terlaksananya kegiatan Rapat Koordinasi Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'dokumen'),
(199, 2018, 4, 3, 1, 1, 22, 403, 13, 4, 9, 'Terlaksananya Rapat Teknis Penanggulangan Kemiskinan Provinsi NTB', '2.00', 'dokumen'),
(200, 2018, 4, 3, 1, 1, 22, 403, 13, 4, 10, 'Terlaksananya Bimtek Penajaman Analisis Belanja Publik Penanggulangan Kemiskinan Provinsi NTB', '1.00', 'dokumen'),
(201, 2018, 4, 3, 1, 1, 22, 403, 13, 5, 11, 'Dokumen perencanaan pengembangan pangan dan pertanian sebagai salah satu acuan dalam pelaksanaan program/kegiatan bidang ekonomi', '0.00', ''),
(202, 2018, 4, 3, 1, 1, 22, 403, 13, 6, 12, 'Penyempurnaan terhadap dokumen perencanaan pembangunan pangan dan pertanian', '0.00', ''),
(203, 2018, 4, 3, 1, 1, 23, 403, 5, 3, 1, 'Tersedianya data dan terjalinnya koordinasi dengan SKPD Mitra', '1.00', 'dokumen'),
(204, 2018, 4, 3, 1, 1, 23, 403, 5, 3, 2, 'Terlaksananya Rakor Program/Kegiatan Kementerian Urusan Pemerintahan dan Politik Tahun 2017', '1.00', 'kegiatan'),
(205, 2018, 4, 3, 1, 1, 23, 403, 5, 4, 3, 'Tersusunnya dokumen perencanaan hasil koordinasi dan evaluasi program pembangunan', '1.00', 'kegiatan'),
(206, 2018, 4, 3, 1, 1, 23, 403, 5, 5, 4, 'Terciptanya perencaan yang efektif dan efisien', '0.00', ''),
(207, 2018, 4, 3, 1, 1, 23, 403, 5, 6, 5, 'Tercapainya target pembangunan sesuai RPJMD', '0.00', ''),
(208, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 1, 'Terselenggaranya rakor dan tersusunnya dokumen Evaluasi PKH', '1.00', 'dokumen'),
(209, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 2, 'Terselenggaranya rakor dan tersusunnya dokumen Evaluasi SLRT', '1.00', 'dokumen'),
(210, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 3, 'Terselenggaranya rakor dan tersusunnya laporan advokasi Percepatan Target RPJMD (PUP dan Kemiskinan)', '1.00', 'dokumen'),
(211, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 4, 'Terselenggaranya rakor sinergitas Kebutuhan Pelatihan Keterampilan (Dunia Usaha, LPK, Dunia Pendidikan)', '1.00', 'kegiatan'),
(212, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 5, 'Terselenggaranya rakor sinergitas Pemberdayaan Buruh Migran', '1.00', 'kegiatan'),
(213, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 6, 'Terselenggaranya rakor sinergitas Ketahanan Keluarga', '1.00', 'kegiatan'),
(214, 2018, 4, 3, 1, 1, 23, 403, 8, 3, 7, 'Terselenggaranya rakor sinegitas Potensi Sumber Kesejaahteraan Sosial ', '1.00', 'kegiatan'),
(215, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 8, 'Terlaksananya Evaluasi PKH', '1.00', 'kegiatan'),
(216, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 9, 'Terlaksananya Evaluasi SLRT', '1.00', 'kegiatan'),
(217, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 10, 'Terlaksananya Advokasi Percepatan Target RPJMD (PUP dan Kemiskinan)', '1.00', 'kegiatan'),
(218, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 11, 'Terlaksananya Kebutuhan Pelatihan Keterampilan (Dunia Usaha, LPK, Dunia Pendidikan)', '1.00', 'kegiatan'),
(219, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 12, 'Terlaksananya Pemberdayaan Buruh Migran', '1.00', 'kegiatan'),
(220, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 13, 'Terlaksananya Ketahanan Keluarga', '1.00', 'kegiatan'),
(221, 2018, 4, 3, 1, 1, 23, 403, 8, 4, 14, 'Terlaksananya Pemetaan Potensi Sumber Kesejahteraan Sosial ', '1.00', 'kegiatan'),
(222, 2018, 4, 3, 1, 1, 23, 403, 8, 5, 15, 'Tercapainya indikator kinerja Sub Bidang Sosial Ketenagakerjaan Kependudukan', '0.00', ''),
(223, 2018, 4, 3, 1, 1, 23, 403, 8, 6, 16, 'Meningkatnya kesejahteraan masyarakat NTB', '0.00', ''),
(224, 2018, 4, 3, 1, 1, 23, 403, 9, 3, 1, 'Konsultasi Publik Raperda Tentang Bale Mediasi', '1.00', 'kegiatan'),
(225, 2018, 4, 3, 1, 1, 23, 403, 9, 3, 2, 'Penyusunan Leaflet tentang Bale Mediasi', '200.00', 'eksemplar'),
(226, 2018, 4, 3, 1, 1, 23, 403, 9, 3, 3, 'Penyusunan Buku Saku tentang Bale Mediasi', '100.00', 'buku'),
(227, 2018, 4, 3, 1, 1, 23, 403, 9, 4, 4, 'Terselenggaranya Konsultasi Publik Ranperda Tentang Bale Mediasi', '1.00', 'kegiatan'),
(228, 2018, 4, 3, 1, 1, 23, 403, 9, 4, 5, 'Tersedianya Leaflet tentang Bale Mediasi', '200.00', 'eksemplar'),
(229, 2018, 4, 3, 1, 1, 23, 403, 9, 4, 6, 'Tersedianya Buku Saku tentang Bale Mediasi', '100.00', 'buku'),
(230, 2018, 4, 3, 1, 1, 23, 403, 9, 5, 7, 'Meningkatnya pemahaman masyarakat tentang Bale Mediasi', '0.00', ''),
(231, 2018, 4, 3, 1, 1, 23, 403, 9, 5, 8, 'Meningkatnya Penyelesaian Sengketa di luar Pengadilan', '0.00', ''),
(232, 2018, 4, 3, 1, 1, 23, 403, 9, 6, 9, 'Meningkatnya Capaian Target Indikator Kinerja Subbidang Pemerintahan Politik ', '0.00', ''),
(233, 2018, 4, 3, 1, 1, 23, 403, 10, 3, 1, 'Dokumen Pelaporan AD PPK', '4.00', 'dokumen'),
(234, 2018, 4, 3, 1, 1, 23, 403, 10, 3, 2, 'Dokumen Pelaporan RAN HAM', '4.00', 'dokumen'),
(235, 2018, 4, 3, 1, 1, 23, 403, 10, 3, 3, 'Rapat Koordinasi AD PPK Provinsi NTB', '1.00', 'kegiatan'),
(236, 2018, 4, 3, 1, 1, 23, 403, 10, 4, 4, 'Tersedianya Laporan Aksi Daerah Pencegahan dan Pemeberantasan Korupsi (AD PPK)', '4.00', 'dokumen'),
(237, 2018, 4, 3, 1, 1, 23, 403, 10, 4, 5, 'Tersedianya Laporan Rencana Aksi Nasional Hak Asasi Manusia (RAN HAM)', '4.00', 'dokumen'),
(238, 2018, 4, 3, 1, 1, 23, 403, 10, 4, 6, 'Terlaksananya Kegiatan Rapat Koordinasi AD PPK Provinsi NTB', '0.00', ''),
(239, 2018, 4, 3, 1, 1, 23, 403, 10, 5, 7, 'Meningkatnya pelaksanaan pencegahan dan pemberantasan korupsi', '0.00', ''),
(240, 2018, 4, 3, 1, 1, 23, 403, 10, 5, 8, 'Meningkatnya pelaksanaan pelaporan RAN HAM', '0.00', ''),
(241, 2018, 4, 3, 1, 1, 23, 403, 10, 6, 9, 'Meningkatnya tata kelola pemerintahan yang baik', '0.00', ''),
(242, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 1, 'Pembentukan  Tim Penyusun Evaluasi Perencanaan dan pelaksanaan kegiatan pendidikan menengah ', '1.00', 'dokumen'),
(243, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 2, 'Terlaksananya kegiatan Generasi Emas NTB di 10 kab/kota di Provinsi NTB', '1.00', 'kegiatan'),
(244, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 3, 'Terselenggaranya Rakor penyelarasan program prioritas nasional dan daerah di bidang pendidikan dan kebudayaan Provinsi NTB', '1.00', 'kegiatan'),
(245, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 4, 'Terselenggaranya Rakor penyelarasan program prioritas nasional dan daerah di bidang Kesehatan Provinsi NTB', '1.00', 'kegiatan'),
(246, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 5, 'Terselenggaranya Lokakarya dalam rangka percepatan penurunan prevalensi kurang Gizi di Provinsi NTB', '1.00', 'kegiatan'),
(247, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 6, 'Terselenggaranya Workshop pembelajaran dalam rangka percepatan Open Defecation Free (ODF) di Provinsi NTB', '1.00', 'kegiatan'),
(248, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 7, 'Tersusunnya Dokumen  RAD PG Provinsi NTB Tahun 2018 - 2023', '1.00', 'dokumen'),
(249, 2018, 4, 3, 1, 1, 23, 403, 11, 3, 8, 'Terselenggaranya Rapat Koordinasi Lintas Pelaku Niaga Garam dengan Tim GAKY tingkat Provinsi NTB', '1.00', 'Dokumen'),
(250, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 9, 'Tersedianya SK Tim Penyusun Perencanaan dan Pelaksanaan kegiatan pendidikan menengah', '1.00', 'Dokumen'),
(251, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 10, 'Tercapainya Target  indikator kinerja Generasi Emas NTB', '1.00', 'kegiatan'),
(252, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 11, 'Terwujudnya penyelarasan program prioritas nasional dan daerah di bidang pendidikan dan kebudayaan Provinsi NTB', '1.00', 'kegiatan'),
(253, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 12, 'Terwujudnya penyelarasan program prioritas nasional dan daerah di bidang Kesehatan Provinsi NTB', '1.00', 'kegiatan'),
(254, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 13, 'Tercapainya konsolidasi lintas sektor dalam rangka percepatan pencapaian target indikator prevalensi kurang gizi di provinsi NTB', '1.00', 'kegiatan'),
(255, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 14, 'Teredukasinya Kabupaten/Kota dalam rangka mewujudkan percepatan ODF di Provinsi NTB ', '1.00', 'kegiatan'),
(256, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 15, 'Tersedianya Dokumen  RAD PG Provinsi NTB Tahun 2018 - 2023', '1.00', 'dokumen'),
(257, 2018, 4, 3, 1, 1, 23, 403, 11, 4, 16, 'Tersusunnya Rekomendasi dalam rangka penguatan Tim GAKY', '1.00', 'dokumen'),
(258, 2018, 4, 3, 1, 1, 23, 403, 11, 5, 17, 'Tercapainya indkator kinerja Bidang Pendidikan dan Kesehatan', '0.00', ''),
(259, 2018, 4, 3, 1, 1, 23, 403, 11, 6, 18, 'Meningkatnya kesehatan dan kecerdasan masyarakat NTB', '0.00', ''),
(260, 2018, 4, 3, 1, 1, 24, 403, 2, 3, 1, 'Laporan Pelaksanaan Geopark Rinjani dan Tambora', '1.00', 'dokumen'),
(261, 2018, 4, 3, 1, 1, 24, 403, 2, 3, 2, 'Laporan pelaksanaan kegiatan Evaluasi Penurunan Emisi Gas Rumah Kaca (GRK) di Provinsi NTB', '1.00', 'dokumen'),
(262, 2018, 4, 3, 1, 1, 24, 403, 2, 3, 3, 'Dokumen Peraturan Gubernur Kelembagaan Geopark Tambora', '1.00', 'dokumen'),
(263, 2018, 4, 3, 1, 1, 24, 403, 2, 3, 4, 'Dokumen Rencana Tapak Penataan Geosite Sarae Nduha', '1.00', 'dokumen'),
(264, 2018, 4, 3, 1, 1, 24, 403, 2, 3, 5, 'Dokumen Perencanaan  Geosite Geopark Rinjani (Persiapan APGN 2019)', '1.00', 'dokumen'),
(265, 2018, 4, 3, 1, 1, 24, 403, 2, 4, 6, 'Terkoordinasinya Pelaksanaan Geopark Rinjani dan Tambora', '1.00', 'kegiatan'),
(266, 2018, 4, 3, 1, 1, 24, 403, 2, 4, 7, 'Terkoordinasinya pelaksanaan kegiatan Evaluasi Penurunan Emisi Gas Rumah Kaca (GRK) di Provinsi NTB', '1.00', 'kegiatan'),
(267, 2018, 4, 3, 1, 1, 24, 403, 2, 4, 8, 'Tersusunnya Peraturan Gubernur Kelembagaan Geopark Tambora', '1.00', 'dokumen'),
(268, 2018, 4, 3, 1, 1, 24, 403, 2, 4, 9, 'Tersusunnya Dokumen Rencana Tapak Penataan Geosite Sarae Nduha', '1.00', 'dokumen'),
(269, 2018, 4, 3, 1, 1, 24, 403, 2, 4, 10, 'Tersusunnya Dokumen Perencanaan  Geosite Geopark Rinjani (Persiapan APGN 2019)', '1.00', 'dokumen'),
(270, 2018, 4, 3, 1, 1, 24, 403, 2, 5, 11, 'Meningkatnya Pengelolaan Sumber Daya Alam Provinsi NTB', '0.00', ''),
(271, 2018, 4, 3, 1, 1, 24, 403, 2, 6, 12, 'Meningkatnya Kelestarian Sumber Daya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(272, 2018, 4, 3, 1, 1, 24, 403, 7, 3, 1, 'Terlaksananya sosialisasi Percepatan Pembangunan Bandar Kayangan', '2.00', 'lokasi'),
(273, 2018, 4, 3, 1, 1, 24, 403, 7, 3, 2, 'Tersedianya database profil infrastruktur strategis Provinsi NTB', '1.00', 'dokumen'),
(274, 2018, 4, 3, 1, 1, 24, 403, 7, 3, 3, 'Tersedianya Peraturan Gubernur mengenai Percepatan Pembangunan Bandar Kayangan', '1.00', 'dokumen'),
(275, 2018, 4, 3, 1, 1, 24, 403, 7, 3, 4, 'Tersedianya dokumen penyelenggaraan DAK di Provinsi NTB', '1.00', 'dokumen'),
(276, 2018, 4, 3, 1, 1, 24, 403, 7, 4, 5, 'Terselenggaranya koordinasi perencanaan bidang pekerjaan umum, permukiman dan transportasi', '1.00', 'kegiatan'),
(277, 2018, 4, 3, 1, 1, 24, 403, 7, 5, 6, 'Terintegrasinya perencanaan bidang pekerjaan umum, permukiman dan transportasi', '0.00', ''),
(278, 2018, 4, 3, 1, 1, 24, 403, 7, 6, 7, 'Perencanaan pembangunan infrastruktur pekerjaan umum permukiman dan transportasi yang berkelanjutan', '0.00', ''),
(279, 2018, 4, 3, 1, 1, 24, 403, 10, 3, 1, 'Dokumen Profil KPI dan Succes Story IPDMIP 2018', '1.00', 'dokumen'),
(280, 2018, 4, 3, 1, 1, 24, 403, 10, 3, 2, 'Dokumen PPMU IPDMI', '1.00', 'dokumen'),
(281, 2018, 4, 3, 1, 1, 24, 403, 10, 4, 3, 'Terdokumentasinya kegiatan IPDMIP dengan baik', '1.00', 'dokumen'),
(282, 2018, 4, 3, 1, 1, 24, 403, 10, 5, 4, 'Tersusunnya dokumen profil KPI dan Succes Story IPDMIP tahun 2018', '0.00', ''),
(283, 2018, 4, 3, 1, 1, 24, 403, 10, 6, 5, 'Meningkatnya pengelolaan sumber daya air', '0.00', ''),
(284, 2018, 4, 3, 1, 1, 24, 403, 11, 3, 1, 'Dokumen Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', '1.00', 'dokumen'),
(285, 2018, 4, 3, 1, 1, 24, 403, 11, 3, 2, 'Dokumen Pelaksanaan Percepatan Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'dokumen'),
(286, 2018, 4, 3, 1, 1, 24, 403, 11, 3, 3, 'Booklet Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'dokumen'),
(287, 2018, 4, 3, 1, 1, 24, 403, 11, 3, 4, 'Roadmap Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'dokumen'),
(288, 2018, 4, 3, 1, 1, 24, 403, 11, 4, 5, 'Terkoordinasinya Kegiatan Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', '1.00', 'kegiatan'),
(289, 2018, 4, 3, 1, 1, 24, 403, 11, 4, 6, 'Terkoordinasi   Pelaksanaan Percepatan Pengembangan Investasi Kawasan Strategis SAMOTA', '1.00', 'kegiatan'),
(290, 2018, 4, 3, 1, 1, 24, 403, 11, 5, 7, 'Meningkatnya Pengelolaan Sumber Daya Alam Provinsi NTB', '0.00', ''),
(291, 2018, 4, 3, 1, 1, 24, 403, 11, 6, 8, 'Meningkatnya Kelestarian Sumber Daya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(292, 2018, 4, 3, 1, 1, 26, 403, 1, 3, 1, 'Perubahan Peraturan Daerah RTRW Provinsi NTB ', '1.00', 'dokumen'),
(293, 2018, 4, 3, 1, 1, 26, 403, 1, 3, 2, 'KLHS Perubahan Perda RTRW Provinsi NTB', '1.00', 'dokumen'),
(294, 2018, 4, 3, 1, 1, 26, 403, 1, 4, 3, 'Tersedianya Perubahan Peraturan Daerah RTRW Provinsi NTB ', '1.00', 'dokumen'),
(295, 2018, 4, 3, 1, 1, 26, 403, 1, 4, 4, 'Tersedianya KLHS Perubahan Perda RTRW Provinsi NTB', '1.00', 'dokumen'),
(296, 2018, 4, 3, 1, 1, 26, 403, 1, 5, 5, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(297, 2018, 4, 3, 1, 1, 26, 403, 1, 6, 6, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(298, 2018, 4, 3, 1, 1, 26, 403, 2, 3, 1, 'Laporan Pelaksanaan Kegiatan BKPRD Provinsi NTB', '1.00', 'dokumen'),
(299, 2018, 4, 3, 1, 1, 26, 403, 2, 3, 2, 'Meningkatnya Peran Badan Koordinasi Penataan Ruang Daerah (BKPRD) Provinsi NTB', '1.00', 'tahun'),
(300, 2018, 4, 3, 1, 1, 26, 403, 2, 5, 3, 'Meningkatnya Pengelolaan Sumberdaya Alam Provinsi NTB', '0.00', ''),
(301, 2018, 4, 3, 1, 1, 26, 403, 2, 6, 4, 'Meningkatnya Kelestarian Sumberdaya Alam dan Kesejahteraan Masyarakat', '0.00', ''),
(302, 2018, 4, 3, 1, 1, 27, 407, 1, 3, 1, 'Tersusunnya Dokumen hasil kajian/penelitian pengembangan ekonomi dan wilayah', '16.00', 'dokumen'),
(303, 2018, 4, 3, 1, 1, 27, 407, 1, 3, 5, 'FGD Kawasan Agroeduwisata Pengembangan Banyu Mulek terlaksana', '75.00', 'org/Laporan'),
(304, 2018, 4, 3, 1, 1, 27, 407, 1, 4, 2, 'Dokumen hasil kajian/penelitian pengembangan ekonomi dan wilayah', '16.00', 'dokumen'),
(305, 2018, 4, 3, 1, 1, 27, 407, 1, 4, 6, 'Laporan FGD Kawasan Agroeduwisata Pengembangan Banyu Mulek ', '75.00', 'org/Laporan'),
(306, 2018, 4, 3, 1, 1, 27, 407, 1, 5, 3, 'Tersedianya hasil kajian/penelitian pengembangan ekonomi dan wilayah yang dapat dijadikan sebagai pedoman dalam penyusunan perencanaan pembangunan daerah daerah', '0.00', ''),
(307, 2018, 4, 3, 1, 1, 27, 407, 1, 6, 4, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(308, 2018, 4, 3, 1, 1, 27, 407, 2, 3, 1, 'Tersususnnya Masterplan Geosite  Tambora', '1.00', 'dokumen'),
(309, 2018, 4, 3, 1, 1, 27, 407, 2, 3, 2, 'Tersusunnya Kajian Pengembangan Cultur Divercity di Tambora', '1.00', 'dokumen'),
(310, 2018, 4, 3, 1, 1, 27, 407, 2, 3, 3, 'Tersusunnya Kajian Geo Homestay Tambora', '1.00', 'dokumen'),
(311, 2018, 4, 3, 1, 1, 27, 407, 2, 3, 4, 'Tersusunnya Kajian Kelembagaan Kawasan Agro Eduwisata Bayumulek', '1.00', 'dokumen'),
(312, 2018, 4, 3, 1, 1, 27, 407, 2, 3, 5, 'Tersusunnya  Buku Melawan Kemiskinan Dari Desa', '1.00', 'dokumen'),
(313, 2018, 4, 3, 1, 1, 27, 407, 2, 4, 6, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'kegiatan'),
(314, 2018, 4, 3, 1, 1, 27, 407, 2, 5, 7, 'ersedianya Telaahan hasil analisa akademis sebagai dasar penyusunan perencanaan dan kebijakan pembangunan daerah', '0.00', ''),
(315, 2018, 4, 3, 1, 1, 27, 407, 2, 6, 8, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(316, 2018, 4, 3, 1, 1, 27, 407, 3, 3, 1, 'Tersusunnya Data dan Informasi Geospasial Daerah', '1.00', 'dokumen'),
(317, 2018, 4, 3, 1, 1, 27, 407, 3, 3, 2, 'Tersebarnya informasi kegiatan Bappeda', '1.00', 'dokumen'),
(318, 2018, 4, 3, 1, 1, 27, 407, 3, 4, 3, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '2.00', 'dokumen'),
(319, 2018, 4, 3, 1, 1, 27, 407, 3, 5, 4, 'Tersedianya kajian teknis dan akademis sebagai dasar penyusunan perencanaan pembangunan daerah', '0.00', ''),
(320, 2018, 4, 3, 1, 1, 27, 407, 3, 6, 5, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(321, 2018, 4, 3, 1, 1, 27, 407, 4, 3, 1, 'Terlaksananya kegiatan Dewan Riset Daerah Provinsi NTB', '1.00', 'tahun'),
(322, 2018, 4, 3, 1, 1, 27, 407, 4, 3, 2, 'Tersampaikannya pemikiran teknokratik dalam rancangan kegiatan rancangan perencanaan', '1.00', 'tahun'),
(323, 2018, 4, 3, 1, 1, 27, 407, 4, 4, 3, 'Meningkatnya kegiatan penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'kegiatan'),
(324, 2018, 4, 3, 1, 1, 27, 407, 4, 5, 4, 'Tersedianya Telaahan hasil analisa akademis sebagai dasar penyusunan perencanaan dan kebijakan pembangunan daerah', '0.00', ''),
(325, 2018, 4, 3, 1, 1, 27, 407, 4, 6, 5, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(326, 2018, 4, 3, 1, 1, 28, 407, 1, 3, 1, 'Terlaksananya Hasil Penelitian', '1.00', 'tahun'),
(327, 2018, 4, 3, 1, 1, 28, 407, 1, 3, 2, 'terlaksananya Pelayanan Ijin penelitian', '1.00', 'tahun'),
(328, 2018, 4, 3, 1, 1, 28, 407, 1, 4, 3, 'Meningkatnya kegiatan hasil penelitian dan pengembangan sebagai bahan masukan bagi perencanaan pembangunan daerah', '1.00', 'kegiatan'),
(329, 2018, 4, 3, 1, 1, 28, 407, 1, 5, 4, 'Tersedianya Ijin Penelitian ', '0.00', ''),
(330, 2018, 4, 3, 1, 1, 28, 407, 1, 6, 5, 'Meningkatnya kualitas perencanaan pembangunan daerah', '0.00', ''),
(331, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 1, 'Lomba Karya Ilmiah Remaja Terlaksana', '1.00', 'laporan'),
(332, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 2, 'Rakor Litbang dan DRD Kab/Kota se NTB Terlaksana', '1.00', 'laporan'),
(333, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 3, 'Sumber Daya Manusia yang terlatih Penulisan Karya Ilmiah', '50.00', 'org/Laporan'),
(334, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 4, 'Seminar/FGD Percepatan Pencapaian SDGs Terlaksana', '1.00', 'laporan'),
(335, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 5, 'Hasil Studi Budidaya Jamur Morel Rinjani tersedia', '1.00', 'laporan'),
(336, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 6, 'Rakor Konsolidasi Data Perencanaan Pembangunan Daerah Provinsi NTB Tahun 2018', '1.00', 'laporan'),
(337, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 7, 'Film Proyek-Proyek Pembangunan Provinsi NTB yang diresmikan pada HUT ke 60 Provinsi NTB tersedia', '1.00', 'dokumen'),
(338, 2018, 4, 3, 1, 1, 28, 407, 2, 3, 8, 'Alat Peraga PUSPA IPTEKDA tersedia', '1.00', 'paket'),
(339, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 10, 'Laporan Lomba Karya Ilmiah Remaja ', '1.00', 'laporan'),
(340, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 11, 'Laporan Rakor Litbang dan DRD Kab/Kota se NTB', '1.00', 'laporan'),
(341, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 12, 'Sumber Daya Manusia yang terlatih Penulisan Karya Ilmiah', '50.00', 'org/Laporan'),
(342, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 13, 'Laporan Seminar/FGD Percepatan Pencapaian SDGs ', '1.00', 'laporan'),
(343, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 14, 'Laporan Hasil Studi Budidaya Jamur Morel Rinjani ', '1.00', 'laporan'),
(344, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 15, 'Laporan Rakor Konsolidasi Data Perencanaan Pembangunan Daerah Provinsi NTB Tahun 2018', '1.00', 'laporan'),
(345, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 16, 'Film Proyek-Proyek Pembangunan Provinsi NTB yang diresmikan pada HUT ke 60 Provinsi NTB ', '1.00', 'dokumen'),
(346, 2018, 4, 3, 1, 1, 28, 407, 2, 4, 19, 'Alat Peraga PUSPA IPTEKDA ', '1.00', 'paket'),
(347, 2018, 4, 3, 1, 1, 28, 407, 2, 5, 17, 'Tersedianya Publikasi Program Unggulan', '0.00', ''),
(348, 2018, 4, 3, 1, 1, 28, 407, 2, 6, 18, 'Meningkatnya Kualitas Perencanaan Pembangunan Daerah ', '0.00', ''),
(349, 2018, 4, 3, 1, 1, 28, 407, 3, 3, 1, 'Naskah Kerjasama tersusun', '8.00', 'naskah'),
(350, 2018, 4, 3, 1, 1, 28, 407, 3, 3, 2, 'Laporan Tahunan Kegiatan Kerjasama Penelitian', '1.00', 'laporan'),
(351, 2018, 4, 3, 1, 1, 28, 407, 3, 4, 3, 'Naskah Kerjasama ', '8.00', 'naskah'),
(352, 2018, 4, 3, 1, 1, 28, 407, 3, 4, 4, 'Laporan Tahunan Kegiatan Kerjasama Penelitian', '1.00', 'laporan'),
(353, 2018, 4, 3, 1, 1, 28, 407, 3, 5, 5, 'Tersedianya naskah Kerjasama', '0.00', ''),
(354, 2018, 4, 3, 1, 1, 28, 407, 3, 6, 6, 'Meningkatnya kualitas perencanaan pembangunan daerah ', '0.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `Id_Prog` smallint(6) NOT NULL,
  `Kd_Keg` smallint(6) NOT NULL,
  `Ket_Kegiatan` varchar(255) NOT NULL,
  `Lokasi` varchar(800) DEFAULT NULL,
  `Kelompok_Sasaran` varchar(255) DEFAULT NULL,
  `Status_Kegiatan` varchar(1) NOT NULL,
  `Pagu_Anggaran` decimal(15,2) DEFAULT NULL,
  `Waktu_Pelaksanaan` varchar(100) DEFAULT NULL,
  `Kd_Sumber` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kegiatan`
--

INSERT INTO `kegiatan` (`Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `Id_Prog`, `Kd_Keg`, `Ket_Kegiatan`, `Lokasi`, `Kelompok_Sasaran`, `Status_Kegiatan`, `Pagu_Anggaran`, `Waktu_Pelaksanaan`, `Kd_Sumber`) VALUES
(2018, 4, 3, 1, 1, 0, 0, 0, 'Non Program', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 1, 'Penyediaan jasa surat menyurat', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 2, 'Penyediaan jasa komunikasi, sumber daya air dan listrik', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 7, 'Penyediaan jasa administrasi keuangan', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 8, 'Penyediaan jasa kebersihan kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 10, 'Penyediaan alat tulis kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 11, 'Penyediaan barang cetakan dan penggandaan', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 12, 'Penyediaan komponen instalasi listrik/penerangan bangunan kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 13, 'Penyediaan peralatan dan perlengkapan kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 17, 'Penyediaan makanan dan minuman', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 18, 'Penyelarasan Program Pemerintah Pusat dan Daerah', 'Jakarta dan Provinsi lainnya', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 19, 'Penyediaan jasa administrasi dan teknis perkantoran', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 1, 403, 20, 'Penyelarasan Program Pemerintah Provinsi dan Kabupaten/Kota', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 2, 403, 22, 'Pemeliharaan rutin/berkala gedung kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 2, 403, 24, 'Pemeliharaan rutin/berkala kendaraan dinas/operasional', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 2, 403, 26, 'Pemeliharaan rutin/berkala perlengkapan gedung kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 2, 403, 30, 'Pemeliharaan rutin/berkala peralatan kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 2, 403, 42, 'Rehabilitasi sedang/berat gedung kantor', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 5, 403, 1, 'Pendidikan dan pelatihan formal', 'di Provinsi NTB', 'Aparatur Perencana di Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 5, 403, 4, 'Peningkatan mental dan fisik aparatur', 'Di Provinsi NTB', 'Aparatur Perencana di Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 6, 403, 4, 'Penyusunan pelaporan keuangan akhir tahun', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 7, 403, 1, 'Peningkatan Manajemen Asset/Barang Milik Daerah', 'di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 15, 403, 1, 'Pengumpulan, updating, dan analisis data informasi capaian target kinerja program dan kegiatan', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 15, 403, 9, 'Penyusunan Data Spasial', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 1, 'Pengembangan partisipasi masyarakat dalam perumusan program dan kebijakan layanan publik', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 5, 'Penyusunan Rancangan RPJMD', 'Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 8, 'Penyusunan rancangan RKPD', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 9, 'Penyelenggaraan musrenbang RKPD', 'Di Provinsi NTB', 'Aparatur perencana, masyarakat  dan dunia usaha', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 11, 'Penyusunan Laporan Kinerja Pemerintah Daerah', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 12, 'Penyusunan laporan Keterangan Pertanggung Jawaban (LKPJ)', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 13, 'Monitoring, evaluasi dan pelaporan', 'Di Provinsi NTB', 'Aparatur, masyarakat', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 14, 'Penyusunan rancangan KUA dan PPAS', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 15, 'Penyusunan Dokumen Perencanaan', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 16, 'Publikasi Perencanaan Pembangunan Daerah', 'Di Provinsi NTB', 'Aparatur dan masyarakat', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 18, 'Evaluasi Dokumen Perencanaan', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 21, 'Pengembangan Sistem Informasi Perencanaan Pembangunan Daerah', 'Di Provinsi NTB', 'SKPD Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 21, 403, 22, 'Penyelarasan Dokumen RPJMD Provinsi NTB', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 22, 403, 10, 'Sosialisasi Ketentuan di Bidang Cukai dan DBHCHT', 'Di Provinsi NTB', 'Aparatur dan masyarakat', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 22, 403, 11, 'Penyusunan perencanaan pembangunan bidang investasi dan keuangan', 'Di Provinsi NTB', 'SKPD Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 22, 403, 12, 'Penyusunan perencanaan pembangunan bidang perindustrian, perdagangan dan pariwisata', 'Di Provinsi NTB', 'SKPD Lingkup Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 22, 403, 13, 'Penyusunan perencanaan bidang pangan dan pertanian', 'Di Provinsi NTB', 'SKPD lingkup Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 23, 403, 5, 'Perencanaan Pembangunan Bidang Pemerintahan', 'Di Provinsi NTB', 'Meningkatnya tata kelola pemerintahan yang baik', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 23, 403, 8, 'Perencanaan Pembangunan Sosial Bidang Kesra', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 23, 403, 9, 'Penguatan Lembaga Mediasi', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 23, 403, 10, 'Evaluasi Aksi Daerah Pemberantasan Korupsi', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 23, 403, 11, 'Perencanaan Pembangunan Sosial Bidang Pendidikan dan Kesehatan', 'Di Provinsi NTB', 'SKPD Lingkup Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 24, 403, 2, 'Penyusunan masterplan pengendalian sumber daya alam dan lingkungan hidup', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 24, 403, 7, 'Perencanaan Pembangunan Bidang Prasarana Wilayah', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 24, 403, 10, 'Sinkronisasi dan Pengendalian Pengelolaan Irigasi Partisipatif', 'Di Provinsi NTB', 'Aparatur', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 24, 403, 11, 'Pemantapan Zonasi Ruang Laut dengan RTRW Provinsi NTB', 'Di Provinsi NTB', 'SKPD Lingkup Provinsi NTB', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 26, 403, 1, 'Penyusunan Rencana Wilayah', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 26, 403, 2, 'Peningkatan Peran Serta BKPRD dalam Perencanaan Pembangunan Wilayah', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 403, 1, 'Penelitian dan pengembangan ekonomi dan wilayah', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 403, 2, 'Penelitian dan pengembangan sosial budaya', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 403, 3, 'Penelitian dan pengembangan informasi geospasial', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 403, 4, 'Peningkatan peran serta dewan riset daerah dalam perencanaan pembangunan', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 407, 1, 'Penelitian dan pengembangan ekonomi dan wilayah', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 407, 2, 'Penelitian dan pengembangan sosial budaya', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 407, 3, 'Penelitian dan pengembangan informasi geospasial', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 27, 407, 4, 'Peningkatan peran serta dewan riset daerah dalam perencanaan pembangunan', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 403, 1, 'Pelayanan Ijin Penelitian', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 403, 2, 'Publikasi Penelitian Unggulan', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 403, 3, 'Kerjasama Penelitian', 'Di Provinsi NTB', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 407, 1, 'Pelayanan Ijin Penelitian', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 407, 2, 'Publikasi Penelitian Unggulan', '', '', '1', '0.00', '', 0),
(2018, 4, 3, 1, 1, 28, 407, 3, 'Kerjasama Penelitian', '', '', '1', '0.00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1436495090),
('m130524_201442_init', 1436495111);

-- --------------------------------------------------------

--
-- Table structure for table `monev`
--

CREATE TABLE `monev` (
  `id` int(11) NOT NULL,
  `id_indikator` int(11) NOT NULL,
  `tgl_keg` date DEFAULT NULL,
  `kinerja` varchar(500) NOT NULL,
  `permasalahan` varchar(500) DEFAULT NULL,
  `resume` varchar(500) DEFAULT NULL,
  `rekomendasi` varchar(500) DEFAULT NULL,
  `doc_sysfilename` varchar(500) DEFAULT NULL,
  `doc_realfilename` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` text,
  `last_name` text,
  `birthdate` date DEFAULT NULL,
  `gender_id` smallint(5) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `first_name`, `last_name`, `birthdate`, `gender_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Yasrul', 'Abdullah', '1974-02-03', 1, '2015-07-30 16:21:39', '2015-07-30 16:21:39'),
(2, 3, 'Abdullah', 'Rawahah', '1979-05-16', 1, '2015-07-30 16:23:56', '2015-07-30 16:23:56'),
(3, 4, 'Fatimah', 'Sholihah', '1978-05-17', 2, '2015-07-30 16:25:15', '2015-07-30 16:25:15'),
(4, 5, 'Hamzah', 'Namira', '1980-08-27', 1, '2015-08-03 09:51:06', '2015-08-03 09:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `Tahun` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `ID_Prog` smallint(6) NOT NULL,
  `Ket_Program` varchar(255) NOT NULL,
  `Tolak_Ukur` varchar(255) DEFAULT NULL,
  `Target_Angka` decimal(15,2) DEFAULT NULL,
  `Target_Uraian` varchar(255) DEFAULT NULL,
  `Kd_Urusan1` tinyint(4) NOT NULL,
  `Kd_Bidang1` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`Tahun`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Kd_Sub`, `Kd_Prog`, `ID_Prog`, `Ket_Program`, `Tolak_Ukur`, `Target_Angka`, `Target_Uraian`, `Kd_Urusan1`, `Kd_Bidang1`) VALUES
(2018, 4, 3, 1, 1, 0, 0, 'Non Program', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 1, 403, 'Program Pelayanan Administrasi Perkantoran', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 2, 403, 'Program Peningkatan Sarana dan Prasarana Aparatur', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 5, 403, 'Program Peningkatan Kapasitas Sumber Daya Aparatur', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 6, 403, 'Program peningkatan pengembangan sistem pelaporan capaian kinerja dan keuangan', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 7, 403, 'Program Peningkatan Kapasitas Pengelolaan Keuangan Daerah', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 15, 403, 'Program pengembangan data/informasi', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 21, 403, 'Program perencanaan pembangunan daerah', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 22, 403, 'Program perencanaan pembangunan ekonomi', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 23, 403, 'Program perencanaan sosial dan budaya', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 24, 403, 'Program perancanaan prasarana wilayah dan sumber daya alam', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 26, 403, 'Program Perencanaan Tata Ruang', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 27, 403, 'Program Penelitian dan Pengembangan', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 27, 407, 'Program Penelitian dan Pengembangan', '', '0.00', '', 4, 7),
(2018, 4, 3, 1, 1, 28, 403, 'Program Peningkatan Pelayanan Penelitian', '', '0.00', '', 4, 3),
(2018, 4, 3, 1, 1, 28, 407, 'Program Peningkatan Pelayanan Penelitian', '', '0.00', '', 4, 7);

-- --------------------------------------------------------

--
-- Table structure for table `program_unit`
--

CREATE TABLE `program_unit` (
  `id` smallint(6) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Kd_Sub` smallint(6) NOT NULL,
  `Kd_Prog` smallint(6) NOT NULL,
  `ID_Prog` smallint(6) NOT NULL,
  `Kd_Keg` smallint(6) NOT NULL,
  `ID_UnitKerja` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `realisasi`
--

CREATE TABLE `realisasi` (
  `id` int(11) NOT NULL,
  `id_indikator` int(11) NOT NULL,
  `tgl_entry` date NOT NULL,
  `fisik` decimal(5,2) NOT NULL,
  `keuangan` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` smallint(6) NOT NULL,
  `role_name` varchar(45) NOT NULL,
  `role_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role_name`, `role_value`) VALUES
(1, 'User', 10),
(2, 'Operator', 20),
(3, 'AdminSystem', 30);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Kd_Bidang` tinyint(4) NOT NULL,
  `Kd_Unit` tinyint(4) NOT NULL,
  `Nm_Unit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `Kd_Urusan`, `Kd_Bidang`, `Kd_Unit`, `Nm_Unit`) VALUES
(1, 1, 1, 1, 'Dinas Pendidikan dan Kebudayaan'),
(2, 1, 2, 1, 'Dinas Kesehatan'),
(3, 1, 2, 2, 'Rumah Sakit Umum Daerah Provinsi'),
(4, 1, 2, 3, 'Rumah Sakit Jiwa Mutiara Sukma Provinsi'),
(5, 1, 2, 4, 'Rumah Sakit H. L. Manambai Abdul Kadir'),
(6, 1, 3, 1, 'Dinas Pekerjaan Umum dan Penataan Ruang'),
(7, 1, 4, 1, 'Dinas Perumahan dan Permukiman'),
(8, 1, 5, 1, 'Badan Kesatuan Bangsa dan Politik Dalam Negeri'),
(9, 1, 5, 2, 'Satuan Polisi Pamong Praja'),
(10, 1, 5, 3, 'Pelaksana Badan Penanggulangan Bencana Daerah Provinsi NTB'),
(11, 1, 6, 1, 'Dinas Sosial'),
(12, 2, 1, 1, 'Dinas Tenaga Kerja dan Transmigrasi'),
(13, 2, 2, 1, 'Dinas Pemberdayaan Perempuan,  Perlindungan Anak, Pengendalian Penduduk dan Keluarga Berencana'),
(14, 2, 3, 1, 'Dinas Ketahanan Pangan'),
(15, 2, 5, 1, 'Dinas Lingkungan Hidup dan Kehutanan'),
(16, 2, 7, 1, 'Dinas Pemberdayaan Masyarakat, Pemerintahan Desa, Kependudukan dan Pencatatan Sipil'),
(17, 2, 9, 1, 'Dinas Perhubungan'),
(18, 2, 10, 1, 'Dinas Komunikasi, Informatika dan Statistik'),
(19, 2, 11, 1, 'Dinas Koperasi Usaha Kecil dan Menengah'),
(20, 2, 12, 1, 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu'),
(21, 2, 13, 1, 'Dinas Pemuda dan Olahraga'),
(22, 2, 17, 1, 'Dinas Perpustakaan dan Kearsipan'),
(23, 3, 1, 1, 'Dinas Kelautan dan Perikanan'),
(24, 3, 2, 1, 'Dinas Pariwisata'),
(25, 3, 3, 1, 'Dinas Pertanian dan Perkebunan'),
(26, 3, 3, 2, 'Dinas Peternakan dan Kesehatan Hewan'),
(27, 3, 5, 1, 'Dinas Energi dan Sumber Daya Mineral'),
(28, 3, 6, 1, 'Dinas Perdagangan'),
(29, 3, 7, 1, 'Dinas Perindustrian'),
(30, 4, 1, 1, 'Dewan Perwakilan Rakyat Daerah'),
(31, 4, 1, 2, 'Kepala Daerah dan Wakil Kepala Daerah'),
(32, 4, 1, 3, 'Sekretariat Daerah'),
(33, 4, 1, 4, 'Sekretariat Dewan Perwakilan Rakyat Daerah'),
(34, 4, 1, 5, 'Badan Penghubung Daerah'),
(35, 4, 2, 1, 'Inspektorat'),
(36, 4, 3, 1, 'Badan Perencanaan Pembangunan, Penelitian dan Pengembangan Daerah'),
(37, 4, 4, 1, 'Badan Pengelolaan Keuangan dan Aset Daerah'),
(38, 4, 4, 2, 'Badan Pengelolaan Pendapatan Daerah'),
(39, 4, 5, 1, 'Badan Kepegawaian Daerah'),
(40, 4, 6, 1, 'Badan Pengembangan Sumber Daya Manusia Daerah');

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE `unit_kerja` (
  `id` smallint(6) NOT NULL,
  `unit_kerja` varchar(255) NOT NULL,
  `id_induk` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_kerja`
--

INSERT INTO `unit_kerja` (`id`, `unit_kerja`, `id_induk`) VALUES
(1, 'Badan Perencanaan Pembagunan, Penelitian dan Pengembangan Daerah', 0),
(2, 'Bidang Sekretariat', 1),
(3, 'Bidang Penelitian dan Pengembangan', 1),
(4, 'Bidang Pemantauan, Evaluasi Dan Pengendalian Perencanaan Pembangunan', 1),
(5, 'Bidang Perencanaan Pembangunan Ekonomi', 1),
(6, 'Bidang Perencanaan Pembangunan Sosial Budaya', 1),
(7, 'Bidang Perencanaan Wilayah Dan Pembangunan Infrastruktur', 1);

-- --------------------------------------------------------

--
-- Table structure for table `urusan`
--

CREATE TABLE `urusan` (
  `Kd_Urusan` tinyint(4) NOT NULL,
  `Nm_Urusan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `urusan`
--

INSERT INTO `urusan` (`Kd_Urusan`, `Nm_Urusan`) VALUES
(1, 'Urusan Wajib Pelayanan Dasar'),
(2, 'Urusan Wajib Bukan Pelayanan Dasar'),
(3, 'Urusan Pilihan'),
(4, 'Urusan Pemerintahan Fungsi Penunjang');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_id` smallint(6) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `status_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `unit_id`, `role_id`, `status_id`, `created_at`, `updated_at`) VALUES
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 3, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'amiruddin', 'IvGFzQ3uvJPi_P3JmqKEXdK0V9YYF7St', '$2y$13$ArWhFm0bGSl9jpZF/xIH1.hqboi..Fi0/oz59JQXnkl4OyArqWzA.', NULL, 'amir@ntbprov.go.id', 3, 4, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Administrator', 'N5yGLBNsIa7oyk35Eq3wiBfZW9cq0Ynp', '$2y$13$QjgGiHcANDFYU5bURinx0Oj3fLE7mLFp9cVyLkAc5w39Kd72IS.xu', NULL, 'yasrul@gmail.com', 5, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'abdullah', '6URjxAyu8dR9n9x_5JYnc68Im6eKhMoY', '$2y$13$xx87TaYGKgmA.ZRRSvUDEuhWtyo9Qs1NyHe4WYKl8buRmZ6v1Og3y', NULL, 'abdullah@gmail.com', 4, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `file_kerja`
--
ALTER TABLE `file_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `indikator`
--
ALTER TABLE `indikator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `monev`
--
ALTER TABLE `monev`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gender_id_idx` (`gender_id`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`Tahun`,`Kd_Urusan`,`Kd_Bidang`,`Kd_Unit`,`Kd_Sub`,`Kd_Prog`,`ID_Prog`);

--
-- Indexes for table `program_unit`
--
ALTER TABLE `program_unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `realisasi`
--
ALTER TABLE `realisasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_kerja`
--
ALTER TABLE `unit_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `file_kerja`
--
ALTER TABLE `file_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `indikator`
--
ALTER TABLE `indikator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=355;
--
-- AUTO_INCREMENT for table `monev`
--
ALTER TABLE `monev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `program_unit`
--
ALTER TABLE `program_unit`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `realisasi`
--
ALTER TABLE `realisasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `gender_id_fk` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
